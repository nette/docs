<?php

/**
 * This file is part of the Nette Framework.
 *
 * Copyright (c) 2004, 2010 David Grudl (http://davidgrudl.com)
 *
 * This source file is subject to the "Nette license", and/or
 * GPL license. For more information please see http://nette.org
 */



/**
 * NComponent with ability to save and load its state.
 *
 * @author     David Grudl
 */
interface IStatePersistent
{

	/**
	 * Loads state informations.
	 * @param  array
	 * @return void
	 */
	function loadState(array $params);

	/**
	 * Saves state informations for next request.
	 * @param  array
	 * @return void
	 */
	function saveState(array & $params);

}
