<?php

/**
 * My Application
 *
 * @copyright  Copyright (c) 2009 John Doe
 * @package    MyApplication
 * @version    $Id: HomepagePresenter.php 182 2008-12-31 00:28:33Z david@grudl.com $
 */



/**
 * Homepage presenter.
 *
 * @author     John Doe
 * @package    MyApplication
 */
class HomepagePresenter extends BasePresenter
{

	public function actionDefault()
	{
		$this->template->title = 'CheckboxList demo';
		$this->template->form = $this->getComponent('form');
	}
	
	protected function createComponent($name)
	{
		switch($name) {
			case 'form':
				$form = new AppForm($this, $name);
				
				$items = array(
					1 => 'Pulp Fiction (ID=1)',
					2 => 'Reservoir Dogs (ID=2)',
					3 => 'Kill Bill (ID=3)',
					4 => 'Jackie Brown (ID=4)',
					5 => 'Desperado (ID=5)',
				);
				$form->addCheckboxList('movies', 'Tarantino already-seen movies', $items)
					->addRule('CheckboxList::validateChecked', 'You haven\'t seen a single movie by Quentin Tarantino!?');
				
				$form->addSubmit('send', 'Send');
				$form->onSubmit[] = array($this, 'formSubmitted');
				break;
			
			default:
				parent::createComponent($name);
		}
	}
	
	public function formSubmitted(Form $form)
	{
		$values = $form->getValues();
		$this->flashMessage('Okay, you have seen enough. Checked: ' . implode(',', $values['movies']));
		$this->redirect('default');
	}

}
