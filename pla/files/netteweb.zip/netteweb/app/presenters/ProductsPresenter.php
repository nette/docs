<?php
class ProductsPresenter extends BasePresenter
{

}
