Callback panel (c) Patrik Votoček (Vrtak-CZ), 2010 (http://patrik.votocek.cz)

Requirements
------------
Nette Framework 1.x or higher. (PHP 5.2 edition)

Documentation and Examples
--------------------------
Documentation and examples is available on:

http://addons.nettephp.com/cs/callbackpanel

Enable
------
For enable add CallbackPanel::register(); to your bootstrap.php.
