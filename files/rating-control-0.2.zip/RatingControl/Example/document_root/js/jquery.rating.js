
jQuery(document).ready(function() {
    var $ = jQuery;
    var i = 0;
    $('.rating-control a').live('mouseover', function() {
            var container = $(this).parent('.rating-control');
            i = container.find('.star-full').size();
            var index = container.find('.rate-star').index($(this).children());
            container.find('.rate-star:lt('+(index+1)+')').addClass('star-full');
            container.find('.rate-star:gt('+index+')').removeClass('star-full');
        }).live('mouseout', function() {
            var container = $(this).parent('.rating-control');
            container.find('.rate-star').removeClass('star-full');
            container.find('.rate-star:lt('+i+')').addClass('star-full');
        });
});