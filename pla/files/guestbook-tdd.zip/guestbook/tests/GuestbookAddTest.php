<?php
require_once dirname(__FILE__) . "/../document_root/index.php";
require_once 'PHPUnit/Extensions/SeleniumTestCase.php';

class GuestbookAddTest extends PHPUnit_Extensions_SeleniumTestCase
{
	protected function setUp()
    {
        $this->setBrowser('*firefox');
        $this->setBrowserUrl("http://localhost/guestbook/document_root/");
    }

    public function testSuccess()
    {
        $this->open();
        $this->type("author", "Jožko");
		$this->type("title", "Titulek");
		$this->type("content", "obsah");
        $this->clickAndWait("save");
        $this->assertTextPresent("byl přidán");
    }
}