<?php
	$file = '../../libs/DependentSelectBox/jquery.nette.dependentselectbox.js';
	header("Content-type: application/javascript");
	header("Cache-Control: no-cache");
	header("Pragma: no-cache");

	if(!file_exists($file))
		echo("alert('Soubor: $file nenalezen !!!');");
	else
		include($file);
