<?php


/**
 * Homepage presenter.
 */
class DefaultPresenter extends BasePresenter
{

    public function createComponentRating($name)
    {
        $rating = new RatingControl($this, $name);
        $rating->setRatingModel(new RatingModel);
    }

}
