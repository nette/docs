Version panel (c) Patrik Votoček (Vrtak-CZ), 2010 (http://patrik.votocek.cz)

Requirements
------------
Nette Framework 1.x or higher. (PHP 5.3 edition)

Documentation and Examples
--------------------------
Documentation and examples is available on:

http://addons.nettephp.com/cs/versionpanel

Enable
------
For enable add Nella\VersionPanel::register(); to your bootstrap.php.
