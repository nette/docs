<?php //netteCache[01]000233a:2:{s:4:"time";s:21:"0.25494300 1264357006";s:9:"callbacks";a:1:{i:0;a:3:{i:0;a:2:{i:0;s:5:"Cache";i:1;s:9:"checkFile";}i:1;s:78:"/opt/lampp/htdocs/guestbook/document_root/../app/templates/Login/default.phtml";i:2;i:1264207986;}}}?><?php
// file …/templates/Login/default.phtml
//

$_cb = LatteMacros::initRuntime($template, NULL, 'c269f0b8b0'); unset($_extends);


//
// block content
//
if (!function_exists($_cb->blocks['content'][] = '_cbb031f3aaff9_content')) { function _cbb031f3aaff9_content() { extract(func_get_arg(0))
?>

<h1>Log in</h1>

<?php $control->getWidget("loginForm")->render() ;
}}

//
// end of blocks
//

if ($_cb->extends) { ob_start(); }

if (SnippetHelper::$outputAllowed) {
extract(array('robots' =>'noindex')) ?>

<?php if (!$_cb->extends) { call_user_func(reset($_cb->blocks['content']), get_defined_vars()); }  
}

if ($_cb->extends) { ob_end_clean(); LatteMacros::includeTemplate($_cb->extends, get_defined_vars(), $template)->render(); }
