<?php
    function createComponentForm($name){
        $f = new AppForm($this,$name);

        $f->addMultipleFileUpload("pokus1","Test�k")
            ->addRule("MultipleFileUpload::validateFilled","Mus�te odeslat alespo� jeden soubor!");

        $f->addMultipleFileUpload("pokus2","Test�k")
            ->addRule("MultipleFileUpload::validateFilled","Mus�te odeslat alespo� jeden soubor!");

        $f->addSubmit("odeslat","Odeslat");

        return $f;
    }