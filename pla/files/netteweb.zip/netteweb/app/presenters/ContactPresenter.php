<?php
class ContactPresenter extends BasePresenter
{

}
