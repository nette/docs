<?php
class HomepagePresenter extends BasePresenter
{

}
