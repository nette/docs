<?php

require LIBS_DIR . '/Nette/loader.php';


Environment::loadConfig();

$dbConfig = Environment::getConfig('database');
$conn = Doctrine_Manager::connection($dbConfig->driver . '://' . $dbConfig->username . ':' . $dbConfig->password . '@' . $dbConfig->host . '/' . $dbConfig->database);

if ($dbConfig->profiler) {
    $profiler = new Doctrine_Connection_Profiler();
    $conn->setListener($profiler);
    Debug::enableProfiler();
    Debug::addColophon('fetchDoctrineEvents');
}


Environment::setVariable('doctrine_config',
    array(
        'data_fixtures_path' => dirname(__FILE__) . '/doctrine/data/fixtures',
        'models_path'        => dirname(__FILE__) . '/models',
        'migrations_path'    => dirname(__FILE__) . '/doctrine/migrations',
        'sql_path'           => dirname(__FILE__) . '/doctrine/data/sql',
        'yaml_schema_path'   => dirname(__FILE__) . '/doctrine/schema'
    )
);


function fetchDoctrineEvents()
{
    $profiler = Doctrine_Manager::getInstance()->getCurrentConnection()->getListener();
    
    $queries = 0;
    $out = '<br />';
    foreach ($profiler as $event) {
        $evName = $event->getName();
    
        if ($evName == 'execute') {
            $queries++;
            $out .= '[' . number_format($event->getElapsedSecs() * 1000, 3) . 'ms]<br />'. $event->getQuery() . '<br />';
        }
    
        $params = $event->getParams();
        if(!empty($params)) {
            $out .= print_r($params, true) . '<br /><br />';
        }
    }
    
    return array(
        $profiler->count() . ' Doctrine events',
        $queries . ' sql queries',
        $out
    );
}