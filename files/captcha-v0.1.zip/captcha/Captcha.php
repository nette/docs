<?php


/**
 * Captcha control.
 *
 * @package	Nette\Extras\Captcha
 */
class Captcha extends TextBase
{
	const KEY = 'key';

	/** text margin */
	const MARGIN = 25;

	/**#@+ character groups */
	const CONSONANTS = 'bcdfghjkmnpqrstvwxz';
	const VOWELS = 'aeiouy';
	/**#@-*/

	/** @var string  default font file */
	public static $defaultFont = '%appDir%/font.ttf';

	/** @var string  default image presenter link mask */
	public static $defaultLinkMask = 'Captcha:show';

	/** @var int  default font size */
	public static $defaultFontSize = 30;

	/** @var int  default number of letters in the image */
	public static $defaultLength = 5;

	/** @var int  default width of the image */
	public static $defaultWidth = 0;

	/** @var int  default height of the image */
	public static $defaultHeight = 0;

	/** @var array  default image text color */
	public static $defaultTextColor = array('red' => 0, 'green' => 0, 'blue' => 0);

	/** @var array  default image background color */
	public static $defaultBgColor = array('red' => 255, 'green' => 255, 'blue' => 255);

	/** @var int  default session timeout (3 hours) */
	public static $defaultTimeout = 10800;

	/** @var string  random session identifier */
	protected $key;

	/** @var string  generated word */
	protected $word;

	/** @var Link|string  link to the image presenter */
	protected $link;

	/** @var Html  container element template */
	protected $container;

	/** @var Html  image template */
	protected $image;

	/** @var string  image font file */
	protected $font;

	/** @var string  image font size */
	protected $fontSize;

	/** @var int  number of letters in the image */
	protected $length;

	/** @var int  width of the image */
	protected $width;

	/** @var int  height of the image */
	protected $height;

	/** @var array  image text color */
	protected $textColor;

	/** @var array  image background color */
	protected $bgColor;

	/** @var int  session timeout */
	protected $timeout;



	/**
	 * Constructor.
	 * @param  string  label
	 */
	public function __construct($label = NULL)
	{
		if (!extension_loaded('gd')) {
			throw new Exception('PHP extension GD is not loaded.');
		}

		$this->monitor('Form');
		parent::__construct($label);

		$this->control->type = 'text';
		$this->filters[] = 'strtolower';
		$this->value = '';
		$this->container = Html::el();
		$this->image = Html::el('img');

		$this->setFontSize(self::$defaultFontSize);
		$this->setLength(self::$defaultLength);
		$this->setWidth(self::$defaultWidth);
		$this->setHeight(self::$defaultHeight);
		$this->setTimeout(self::$defaultTimeout);
		$this->setTextColor(self::$defaultTextColor);
		$this->setBgColor(self::$defaultBgColor);

		$session = $this->getSession();
		if (!$session->isStarted()) {
			$session->start();
		}
	}



	/**
	 * This method will be called when the component (or component's parent)
	 * becomes attached to a monitored object. Do not call this method yourself.
	 * @param  IComponent
	 * @return void
	 */
	protected function attached($form)
	{
		if ($form instanceof Form) {
			$name = $this->getKeyName();
			$form[$name] = new HiddenField($this->getKey());
		}
	}



	/**
	 * Loads HTTP data.
	 * @param  array
	 * @return void
	 */
	public function loadHttpData($data)
	{
		$name = $this->getKeyName();
		if (isset($data[$name])) {
			$key = $data[$name];
			if ($this->loadState($key)) {
				$session = $this->getStateSession();
				unset($session->$key);
				parent::loadHttpData($data);
				if ($this->tmpValue !== $this->word) {
					$this->tmpValue = '';
				}
			}
		}
	}



	/**
	 * Returns random session identifier.
	 * @return string
	 */
	public function getKey()
	{
		if (!isset($this->key)) {
			$session = $this->getStateSession();
			do {
				$key = substr(md5(lcg_value()), 0, 4);
			} while (isset($session->$key));
			$this->key = $key;
		}

		return $this->key;
	}



	/**
	 * Returns generated word.
	 * @return string
	 */
	public function getWord()
	{
		if (!isset($this->word)) {
			$s = '';
			for ($i = 0; $i < $this->length; $i++) {
				$group = $i % 2 === 0 ? self::CONSONANTS : self::VOWELS;
				$s .= $group{mt_rand(0, strlen($group) - 1)};
			}
			$this->word = $s;
		}

		return $this->word;
	}



	/**
	 * Sets link to the image presenter.
	 * @param  Link|string
	 * @return  Captcha  provides a fluent interface
	 */
	public function setLink($link)
	{
		$this->link = $link;
		return $this;
	}



	/**
	 * Returns link to the image presenter.
	 * @param  bool  throw exception if link autocreation fails?
	 * @return Link|string
	 */
	public function getLink($need = FALSE)
	{
		if (!isset($this->link)) {
			$presenter = $this->lookup('Presenter');
			if ($presenter !== NULL) {
				$this->link = $presenter->lazyLink(self::$defaultLinkMask);
			}

			if ($need && $this->link === NULL) {
				throw new InvalidStateException('Component must be attached to presenter for link autocreation.');
			}
		}

		return $this->link;
	}



	/**
	 * Sets image font file.
	 * @param  string
	 * @return Captcha  provides a fluent interface
	 */
	public function setFont($file)
	{
		$file = Environment::expand($file);

		if (!is_file($file) || !is_readable($file)) {
			throw new FileNotFoundException("Font file '$file' is missing or is not readable.");
		}

		$this->font = realpath($file);
		return $this;
	}



	/**
	 * Returns image font file.
	 * @param  bool   throw exception if no font is set?
	 * @return string
	 */
	public function getFont($need = FALSE)
	{
		if (!isset($this->font)) {
			try {
				$this->setFont(self::$defaultFont);
			} catch (FileNotFoundException $e) {
				if ($need) {
					throw $e;
				}

				return NULL;
			}
		}

		return $this->font;
	}



	/**
	 * Sets image font size.
	 * @param  int
	 * @return Captcha  provides a fluent interface
	 */
	public function setFontSize($size)
	{
		$this->fontSize = (int) $size;
		return $this;
	}



	/**
	 * Returns image font size.
	 * @return int
	 */
	final public function getFontSize()
	{
		return $this->fontSize;
	}



	/**
	 * Sets the number of letters in the image.
	 * @param  int
	 * @return Captcha  provides a fluent interface
	 */
	public function setLength($length)
	{
		$this->length = (int) $length;
		return $this;
	}



	/**
	 * Returns the number of letters in the image.
	 * @return int
	 */
	final public function getLength()
	{
		return $this->length;
	}



	/**
	 * Sets the image width.
	 * @param  int
	 * @return Captcha  provides a fluent interface
	 */
	public function setWidth($width)
	{
		$this->width = (int) $width;
		return $this;
	}



	/**
	 * Returns the image width.
	 * @return int
	 */
	final public function getWidth()
	{
		return $this->width;
	}



	/**
	 * Sets the image height.
	 * @param  int
	 * @return Captcha  provides a fluent interface
	 */
	public function setHeight($height)
	{
		$this->height = (int) $height;
		return $this;
	}



	/**
	 * Returns the image height.
	 * @return int
	 */
	final public function getHeight()
	{
		return $this->height;
	}



	/**
	 * Sets the default session timeout.
	 * @param  int  number of seconds
	 * @return Captcha  provides a fluent interface
	 */
	public function setTimeout($seconds)
	{
		$this->timeout = (int) $seconds;
		return $this;
	}



	/**
	 * Returns the session timeout.
	 * @return int
	 */
	final public function getTimeout()
	{
		return $this->timeout;
	}



	/**
	 * Sets the image text color.
	 * @param  array
	 * @return Captcha  provides a fluent interface
	 */
	public function setTextColor(array $color)
	{
		$color['alpha'] = 0;
		$this->textColor = $color;
		return $this;
	}



	/**
	 * Returns the image text color.
	 * @return array
	 */
	final public function getTextColor()
	{
		return $this->textColor;
	}



	/**
	 * Sets the image background color.
	 * @param  array
	 * @return Captcha  provides a fluent interface
	 */
	public function setBgColor(array $color)
	{
		$color['alpha'] = 0;
		$this->bgColor = $color;
		return $this;
	}



	/**
	 * Returns the image background color.
	 * @return array
	 */
	final public function getBgColor()
	{
		return $this->bgColor;
	}



	/**
	 * Returns container HTML element template.
	 * @return Html
	 */
	final public function getContainerPrototype()
	{
		return $this->container;
	}



	/**
	 * Returns image HTML element template.
	 * @return Html
	 */
	final public function getImagePrototype()
	{
		return $this->image;
	}



	/**
	 * Returns the name of the key hidden field.
	 * @return string
	 */
	public function getKeyName()
	{
		return $this->name . '__' . self::KEY;
	}



	/**
	 * Generates control's HTML element.
	 * @return Html
	 */
	public function getControl()
	{
		$container = clone $this->container;
		$container->add($this->getImage());
		$container->add($this->getInput());

		return $container;
	}



	/**
	 * Generates images's HTML element.
	 * @return Html
	 */
	public function getImage()
	{
		$link = $this->getLink(TRUE);
		if ($link instanceof Link) {
			$link = clone $link;
			$link->setParam(self::KEY, $this->getKey());
		} else {
			$link .= strpos($link, '?') !== FALSE ? '&' : '?';
			$link .= self::KEY . '=' . $this->getKey();
		}

		$this->detectDimensions();

		$image = clone $this->image;
		$image->src = (string) $link;
		$image->width = $this->width;
		$image->height = $this->height;
		$image->alt = (string) $image->alt;

		return $image;
	}



	/**
	 * Generates input's HTML element.
	 * @return Html
	 */
	public function getInput()
	{
		$this->saveState();

		$control = parent::getControl();
		$control->value = $this->value === '' ? $this->emptyValue : $this->tmpValue;

		return $control;
	}



	/**
	 * Sends image data to the browser.
	 * @return void
	 */
	public function send($type = Image::PNG)
	{
		$this->getHttpResponse()->expire(0);
		$this->getImageData()->send($type);
	}



	/**
	 * Generates image data.
	 * @return Image
	 */
	public function getImageData()
	{
		$word = $this->getWord();
		$font = $this->getFont(TRUE);
		$size = $this->fontSize;
		$textColor = $this->textColor;
		$bgColor = $this->bgColor;

		$box = $this->detectDimensions();
		$width = $this->width;
		$height = $this->height;

		$first = Image::fromBlank($width, $height, $bgColor);
		$second = Image::fromBlank($width, $height, $bgColor);

		$x = ($width - $box['width']) / 2;
		$y = ($height + $box['height']) / 2;

		$first->fttext($size, 0, $x, $y, $textColor, $font, $word);

		$frequency = $this->random(0.05, 0.1);
		$amplitude = $this->random(2, 4);
		$phase = $this->random(0, 6);

		for ($x = 0; $x < $width; $x++) {
			for ($y = 0; $y < $height; $y++) {
				$sy = round($y + sin($x * $frequency + $phase) * $amplitude);
				$sx = round($x + sin($y * $frequency + $phase) * $amplitude);

				$color = $first->colorat($x, $y);
				$second->setpixel($sx, $sy, $color);
			}
		}

		$first->destroy();

		$second->filter(IMG_FILTER_SMOOTH, 1);
		$second->filter(IMG_FILTER_CONTRAST, -60);

		return $second;
	}



	/**
	 * Detects image dimensions and returns image text bounding box.
	 * @return array
	 */
	protected function detectDimensions()
	{
		$box = imagettfbbox($this->fontSize, 0, $this->getFont(TRUE), $this->getWord());
		$box['width'] = $box[2] - $box[0];
		$box['height'] = $box[3] - $box[5];

		if ($this->width === 0) {
			$this->width = $box['width'] + self::MARGIN;
		}
		if ($this->height === 0) {
			$this->height = $box['height'] + self::MARGIN;
		}

		return $box;
	}



	/**
	 * Returns a random number within the specified range.
	 * @param  float  lowest value
	 * @param  float  highest value
	 * @return float
	 */
	protected function random($min, $max)
	{
		return mt_rand() / mt_getrandmax() * ($max - $min) + $min;
	}



	/**
	 * Saves state information for image generation.
	 * @return void
	 */
	public function saveState()
	{
		$key = $this->getKey();
		$session = $this->getStateSession();

		$session->$key = array(
			'word' => $this->getWord(),
			'font' => $this->getFont(TRUE),
			'fontSize' => $this->fontSize,
			'length' => $this->length,
			'width' => $this->width,
			'height' => $this->height,
			'textColor' => $this->textColor,
			'bgColor' => $this->bgColor,
		);

		$session->setExpiration($this->timeout, $key);
	}



	/**
	 * Loads state information for image generation.
	 * @param  string  session identifier
	 * @return bool  was successful?
	 */
	public function loadState($key)
	{
		$session = $this->getStateSession();
		if (!isset($session->$key)) {
			return FALSE;
		}
		foreach ($session->$key as $name => $value) {
			$this->$name = $value;
		}

		return TRUE;
	}



	/**
	 * Valid validator: is control valid?
	 * @param  IFormControl
	 * @return bool
	 */
	public static function validateValid(IFormControl $control)
	{
		return $control->getValue() === $control->getWord();
	}



	/**
	 * Form container extension method. Do not call directly.
	 * @param  Form
	 * @param  string  name
	 * @param  string  label
	 * @return Captcha
	 */
	public static function addCaptcha(Form $form, $name, $label)
	{
		return $form[$name] = new self($label);
	}



	/**
	 * @return SessionNamespace
	 */
	protected function getStateSession()
	{
		return $this->getSession()->getNamespace('Nette.Extras.Captcha/states');
	}



	/**
	 * @return HttpResponse
	 */
	protected function getHttpResponse()
	{
		return Environment::getHttpResponse();
	}



	/**
	 * @return Session
	 */
	protected function getSession()
	{
		return Environment::getSession();
	}

}



/** add Nette\FormContainer method */
FormContainer::extensionMethod('addCaptcha', array('Captcha', 'addCaptcha'));
