<?php
use \NiftyGrid\Grid;

class CommentGridByArticleId extends Grid
{
	protected $comments;

	protected $article_id;

	public function __construct($comments, $article_id)
	{
		parent::__construct();
		$this->comments = $comments;
		$this->article_id = $article_id;
	}

	protected function configure($presenter)
	{
		$source = new \NiftyGrid\NDataSource($this->comments->select('comment.id, title, user.username')->where('article_id = ?', $this->article_id));

		$this->setDataSource($source);


		$this->addColumn("title", "Titulek", "350px")
			->setTextFilter()
			->setAutocomplete(5)
			->setTextEditable();

		$this->addColumn("username", "Autor", "250px")
			->setTableName("user.username")
			->setTextFilter()
			->setAutocomplete(5)
			->setSelectEditable($presenter->context->database->table('user')->fetchPairs('id','username'));

		$self = $this;

		$this->addButton(Grid::ROW_FORM)
			->setLabel("Rychlá editace")
			->setClass("fast-edit");

		$this->addButton("deleteButton", "Smazat")
			->setClass("delete")
			->setLink(function($row) use($self){return $self->link("delete!", $row['id']);})
			->setConfirmationDialog(function($row){return "Určitě chcete komentář '$row[title]' smazat?";});


		$this->setRowFormCallback(function($values) use ($self, $presenter){
				$vals = array(
					"title" => $values["title"],
					"user_id" => $values["username"],
				);
				$presenter->context->database->table('comment')->where("id = ?", $values["id"])->update($vals);
				$self->flashMessage("Komentář '$values[title]' byl úspěšně upraven","info");
			}
		);

		$this->addAction("delete", "Smazat")
			->setCallback(function($id) use ($self){
			return $self->handleDelete($id);
		});
	}

	public function handleDelete($id)
	{
		$this->flashMessage("V ukázkové aplikaci nelze mazat záznamy.", "grid-info");
	}
}