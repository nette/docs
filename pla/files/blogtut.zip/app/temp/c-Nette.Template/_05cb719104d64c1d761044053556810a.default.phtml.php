<?php //netteCache[01]000243a:2:{s:4:"time";s:21:"0.64844500 1281209426";s:9:"callbacks";a:1:{i:0;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:73:"C:\wamp\www\blogtut\document_root/../app/templates/Homepage/default.phtml";i:2;i:1281209421;}}}?><?php
// file …/templates/Homepage/default.phtml
//

use Nette\Templates\LatteMacros, Nette\Templates\TemplateHelpers, Nette\SmartCachingIterator, Nette\Web\Html, Nette\Templates\SnippetHelper, Nette\Debug, Nette\Environment, Nette\Templates\CachingHelper, Nette\Application\InvalidLinkException;

$_cb = LatteMacros::initRuntime($template, NULL, '384f5ecbed'); unset($_extends);


//
// block content
//
if (!function_exists($_cb->blocks['content'][] = '_cbbc0ad40c1ed_content')) { function _cbbc0ad40c1ed_content() { extract(func_get_arg(0))
?>
<h1>Můj blogísek</h1>
<div id="posts">
<?php foreach ($iterator = $_cb->its[] = new SmartCachingIterator($posts) as $post): ?>
    <div class="post">
        <h3><?php echo TemplateHelpers::escapeHtml($post['title']) ?></h3>
        <small>Přidáno <?php echo TemplateHelpers::escapeHtml($template->date($post['date'])) ?></small>
        <p><?php echo TemplateHelpers::escapeHtml($template->truncate($post['body'], 300)) ?></p>
        <a href="<?php echo TemplateHelpers::escapeHtml($presenter->link("single", array($post['id']))) ?>">Více...</a>
    </div>
<?php endforeach; array_pop($_cb->its); $iterator = end($_cb->its) ?>
</div><?php
}}

//
// end of blocks
//

if ($_cb->extends) { ob_start(); }

if (SnippetHelper::$outputAllowed) {
if (!$_cb->extends) { call_user_func(reset($_cb->blocks['content']), get_defined_vars()); }  
}

if ($_cb->extends) { ob_end_clean(); LatteMacros::includeTemplate($_cb->extends, get_defined_vars(), $template)->render(); }
