<?php

/**
 * Homepage presenter.
 *
 * @author     John Doe
 * @package    MyApplication
 */
class HomepagePresenter extends BasePresenter {

	protected function startup() {
		parent::startup();
		\DependentSelectBox\DependentSelectBox::register('addDSelect');
		\DependentSelectBox\JsonDependentSelectBox::register('addJSelect');
	}
	
	protected function beforeRender() {
		parent::beforeRender();
		DependentSelectBox\JsonDependentSelectBox::tryJsonResponse($this);
	}
	
	public function renderDefault() {
	}

	protected function createComponentForm($name) {
		$form = new Nette\Application\UI\Form($this, $name);
		
		$form->addSelect('select1', 'Select 1', array('a' => 'a', 'b' => 'b', 'c' => 'c'));
		
		$form->addDSelect('select2', 'Select 2', $form['select1'], function($form) {
			$v = $form['select1']->getValue();
			return array("$v 1" => "$v 1", "$v 2" => "$v 2", "$v 3" => "$v 3");
		});
		
		$presenter = $this;
		if($this->isAjax()) {
			$form['select2']->addOnSubmitCallback(function() use($presenter) {
				$presenter->invalidateControl('formSnippet');
			});
		}
		
		$form->addSubmit('show', 'Show')->onClick[] = function($button) {
			dump($button->form->values);
		};
		return $form;
	}
	
	
	protected function createComponentJsonForm($name) {
		$form = new Nette\Application\UI\Form($this, $name);
		
		$form->addSelect('select1', 'Select 1', array('A' => 'A', 'B' => 'B', 'C' => 'C'));
		
		$form->addJSelect('select2', 'Select 2', $form['select1'], function($form) {
			$v = $form['select1']->getValue();
			return array("$v 10" => "$v 10", "$v 20" => "$v 20", "$v 30" => "$v 30");
		});
		
		$presenter = $this;
		if($this->isAjax()) {
			$form['select2']->addOnSubmitCallback(function() use($presenter) {
				$presenter->invalidateControl('jsonFormSnippet');
			});
		}
		
		$form->addSubmit('show', 'Show')->onClick[] = function($button) {
			dump($button->form->values);
		};
		return $form;
	}	
}
