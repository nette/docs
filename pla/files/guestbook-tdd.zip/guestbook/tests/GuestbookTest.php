<?php
require_once "PHPUnit/Framework.php";
require_once dirname(__FILE__) . "/../document_root/index.php";

/**
 * Test of Guestbook model
 */
class GuestbookTest extends PHPUnit_Framework_TestCase
{
	/** @var Guestbook */
	private $model;

	protected function setUp()
	{
		$this->model = new Guestbook;
		dibi::query("DELETE FROM %n", $this->model->table);
	}

	public function testInsert()
	{
		$values = array(
			'author' => 'Jožko',
			'email' => 'jozko@gmail.com',
			'title' => 'Lorem',
			'content' => 'Ipsum dolor sit amet',
			'added' => new DateTime(),
		);
		$this->model->insert($values);
		$this->model->insert($values);
		$this->assertEquals(2, dibi::fetchSingle("SELECT COUNT([id]) FROM %n", $this->model->table));
	}

	public function testSelect()
	{
		$this->testInsert();
		$rows = $this->model->fetchAll();
		$this->assertEquals(2, count($rows));
	}

	public function testDelete()
	{
		$this->testInsert();
		$id = dibi::fetchSingle("SELECT MAX([id]) FROM %n", $this->model->table);
		$this->model->delete($id);
		$this->assertEquals(1, dibi::fetchSingle("SELECT COUNT([id]) FROM %n", $this->model->table));
	}
}