<?php

/**
 * My Application
 *
 * @copyright  Copyright (c) 2010 John Doe
 * @package    MyApplication
 */



/**
 * Users authenticator.
 *
 * @author     John Doe
 * @package    MyApplication
 */
class UsersModel extends Object implements IAuthenticator
{
	const VALID_USERNAME = 'admin';
	const VALID_PASSWORD = '21232f297a57a5a743894a0e4a801fc3';

	/**
	 * Performs an authentication
	 * @param  array
	 * @return IIdentity
	 * @throws AuthenticationException
	 */
	public function authenticate(array $credentials)
	{
		$username = $credentials['username'];
		$password = md5($credentials['password']);
		
		if ($username !== self::VALID_USERNAME) {
			throw new AuthenticationException("User '$username' not found.", self::IDENTITY_NOT_FOUND);
		}

		if ($password !== self::VALID_PASSWORD) {
			throw new AuthenticationException("Invalid password.", self::INVALID_CREDENTIAL);
		}
		
		return new Identity(1, 'admin', array());
	}
}