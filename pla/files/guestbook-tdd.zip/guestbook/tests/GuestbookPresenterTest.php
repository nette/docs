<?php
require_once dirname(__FILE__) . "/../document_root/index.php";
require_once "PHPUnit/Framework.php";

/**
 * Test of Guestbook Presenter
 */
class GuestbookPresenterTest extends PHPUnit_Framework_TestCase
{
	/** @var GuestbookPresenter */
	private $object;

	protected function setUp()
	{
		$this->object = new GuestbookPresenter;
	}

	public function testSeeAddItemForm()
	{
		$requestData = array(
			'action' => 'default'
		);
		$request = new PresenterRequest('Guestbook', 'POST', $requestData);
		$response = $this->object->run($request);
		$this->assertType("AppForm", $response->getSource()->presenter['addItemForm']);
	}

	public function testFillFormAndRedirect()
	{
		$requestData = array(
			'action' => 'default',
			'do' => 'addItemForm-submit', // signál
			'add' => 'add', // tlačítko (submit button)

			// dále následují data
			'author' => 'Jožko',
			'email' => 'jozko@gmail.com',
			'title' => 'Lorem',
			'content' => 'Ipsum dolor sit amet',
		);
		$request = new PresenterRequest('Guestbook', 'POST', $requestData, $requestData);
		$response = $this->object->run($request);
		$this->assertType('RedirectingResponse', $response);
	}

	public function testFillFormAndNotRedirect()
	{
		$requestData = array(
			'action' => 'default',
			'do' => 'addItemForm-submit', // signál

			// dále následují data formuláře
			'save' => 'save', // tlačítko (submit button)
		);
		$request = new PresenterRequest('Guestbook', 'POST', $requestData, $requestData);
		$response = $this->object->run($request);
		$this->assertType('RenderResponse', $response); // aplikace nás musí přesměrovat
	}

	public function testDoNotAllowDelete()
	{
		$requestData = array(
			'action' => 'default',
			'do' => 'delete',
			'id' => 1,
		);
		$request = new PresenterRequest('Guestbook', 'GET', $requestData, $requestData);
		try {
			$response = $this->object->run($request);
		} catch (Exception $e) {
			$this->assertType('ForbiddenRequestException', $e);
		}
	}

	public function testAllowDeleteWhenLogged()
	{
		$this->object->loggedIn = TRUE;
		$requestData = array(
			'action' => 'default',
			'do' => 'delete',
			'id' => 1,
		);
		$request = new PresenterRequest('Guestbook', 'GET', $requestData, $requestData);
		$response = $this->object->run($request);
		$this->assertType('RedirectingResponse', $response);
	}
}