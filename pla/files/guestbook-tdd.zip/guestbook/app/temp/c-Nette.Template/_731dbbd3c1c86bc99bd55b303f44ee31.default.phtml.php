<?php //netteCache[01]000237a:2:{s:4:"time";s:21:"0.73293700 1264356998";s:9:"callbacks";a:1:{i:0;a:3:{i:0;a:2:{i:0;s:5:"Cache";i:1;s:9:"checkFile";}i:1;s:82:"/opt/lampp/htdocs/guestbook/document_root/../app/templates/Guestbook/default.phtml";i:2;i:1264356996;}}}?><?php
// file …/templates/Guestbook/default.phtml
//

$_cb = LatteMacros::initRuntime($template, NULL, '6316b6d440'); unset($_extends);


//
// block content
//
if (!function_exists($_cb->blocks['content'][] = '_cbb91c33cd139_content')) { function _cbb91c33cd139_content() { extract(func_get_arg(0))
;if (SnippetHelper::$outputAllowed) { ?>
<p><a href="<?php echo TemplateHelpers::escapeHtml($presenter->link("Login:")) ?>">Přihlašte se</a></p>
<h1>Přidejte nový příspěvek</h1>
<?php $control->getWidget("addItemForm")->render() ;} if ($_cb->foo = SnippetHelper::create($control, "itemlist")) { $_cb->snippets[] = $_cb->foo ;foreach ($iterator = $_cb->its[] = new SmartCachingIterator($items) as $item): ?>
<div id="itemlist">

	<div class="item">
		<div class="title">
			<strong class="title"><?php echo TemplateHelpers::escapeHtml($item->title) ?></strong> (<?php if ($item->email): ?><a href="mailto:<?php echo TemplateHelpers::escapeHtml($item->email) ?>"><?php endif ;echo TemplateHelpers::escapeHtml($item->author) ;if (isset($item->email)): ?></a><?php endif ?> @
			<?php echo TemplateHelpers::escapeHtml($template->date($item->added, '%d.%m.%Y')) ?>)
		</div>
		<div class="content"><?php echo TemplateHelpers::escapeHtml($item->content) ?></div>
		<?php if ($user->isAuthenticated()): ?><a href="<?php echo TemplateHelpers::escapeHtml($control->link("delete!", array($item->id))) ?>" class="ajax delete-link">Smazat</a><?php endif ?>

	</div>
</div>
<?php endforeach; array_pop($_cb->its); $iterator = end($_cb->its) ;array_pop($_cb->snippets)->finish(); } if (SnippetHelper::$outputAllowed) { 
}}

//
// end of blocks
//

if ($_cb->extends) { ob_start(); }

if (SnippetHelper::$outputAllowed) {
} if (!$_cb->extends) { call_user_func(reset($_cb->blocks['content']), get_defined_vars()); }  
}

if ($_cb->extends) { ob_end_clean(); LatteMacros::includeTemplate($_cb->extends, get_defined_vars(), $template)->render(); }
