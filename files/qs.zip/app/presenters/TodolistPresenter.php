<?php
/**
 * @property-read TodoManager $model
 */
final class TodolistPresenter extends BasePresenter
{
	/** @var TodoManager */
    private $todoManager = NULL;

    public function actionShow($showDoneTasks = FALSE)
	{
        
    }

    public function renderShow($showDoneTasks)
	{
		$this->invalidateControl();

		$where = array(
			'done' => $showDoneTasks ? 'yes' : 'no',
		);
		
		$vp = $this['vp'];
		$paginator = $vp->paginator; // alias
		$paginator->itemsPerPage = 5;
		$paginator->itemCount = $this->model->todoCount($where);
		$todos = $this->model->findAllTodos($order = array(
			'added' => 'ASC',
		), $where, $paginator->offset, $paginator->itemsPerPage);

		$this->template->todos = $todos;
		$this->template->showDone = $showDoneTasks;
    }

	public function renderAdd()
	{
		$this->invalidateControl('todolist');
	}


	/**
	 * Signál, který změní done na opačnou hodnotu
	 *
	 * @param int $id
	 */
	public function handleChangeState($id)
	{
		$this->flashMessage('Stav byl změněn.');

		$todo = $this->model->findTodo($id);
		if($todo) {
			$todo->changeState();
		}
		
		if(!$this->isAjax()) {
			$this->redirect('this', !$this->getParam('showDoneTasks'));
		} else {
			$this->forward('this', !$this->getParam('showDoneTasks'));
		}
	}

	/**
	 * Signál, který smaže úkol s id = $id
	 *
	 * @param int $id
	 */
	public function handleDelete($id)
	{
		$this->flashMessage('Úkol smazán.');

		$todo = $this->model->findTodo($id);
		if($todo) {
			$todo->delete();
		}
		
		if(!$this->isAjax()) {
			$this->redirect('this');
		}
	}

	/**
	 * Stránkovadlo
	 *
	 * @return VisualPaginator
	 */
	public function createComponentVp()
	{
		return new VisualPaginator;
	}

	/**
	 * Továrnička na formulář
	 *
	 * @return AppForm
	 */
	public function createComponentTodoForm()
	{
		$form = new AppForm;
		$form->getElementPrototype()->class('ajaxform');
		$form->addText('text', 'Úkol', 60, 100)
			  ->addRule(Form::FILLED, 'Musíte vyplnit text!');
		$form->addSubmit('save', 'Uložit');
		$form->addSubmit('back', 'Zpět')->setValidationScope(NULL);

		$form->onSubmit[] = callback($this, 'processTodoForm');

		return $form;
	}

	/**
	 * Zpracování formuláře - přidávání úkolů
	 * 
	 * @param AppForm $form
	 */
	public function processTodoForm(AppForm $form)
	{
		if($form['save']->isSubmittedBy()) {
			$values = $form->getValues();

			$todo = new Todo;
			$todo->text = $values['text'];
			$todo->added = new DateTime;
			$this->model->createTodo($todo);

			$this->invalidateControl();
			$this->flashMessage('Úkol vložen.');
		}
		
		if(!$this->isAjax()) {
			$this->redirect('Todolist:show');
		} else {
			$this->forward('Todolist:show');
		}
	}

	/**
	 * Getter pro model
	 *
	 * @return TodoManager
	 */
	public function getModel()
	{
        if(!isset($this->todoManager))
            $this->todoManager = new TodoManager;

        return $this->todoManager;
    }
}