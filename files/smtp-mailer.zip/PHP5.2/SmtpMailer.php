<?php
/**
 * Nette Framework
 *
 * Copyright (c) 2008, 2010 Patrik Votoček (http://patrik.votocek.cz)
 * 
 * @copyright	Copyright (c) 2008, 2009 Patrik Votoček
 * @license		New-BSD
 * @link		http://addons.nette.org/cs/smtpmailer
 * @see			http://github.com/Vrtak-CZ/SmtpMailer
 * @category	Nette
 * @package		Nette\Mail
 */

/*namespace Nette\Mail;*/

/**
 * SMTP send mail mailer
 *
 * @copyright	Copyright (c) 2008, 2010 Patrik Votoček
 * @author		Patrik Votoček
 * @author		Martin Pecka <peci1@seznam.cz>
 * @package		Nette\Mail
 */
class SmtpMailer extends SendmailMailer
{
	/** @var array */
	protected $config;
	/** @var int */
	protected $connection = NULL;
	/** @var int */
	protected $state;
	/** @var stdClass */
	protected $response;
	/** @var string */
	protected $request;

	const MAX_RESPONSE_LENGTH = 515;

	const STATE_DISCONNECTED = 0;
	const STATE_CONNECTED = 1;

	const TRANSPORT_TCP = 'tcp';
	const TRANSPORT_SSL = 'ssl';
	const TRANSPORT_SSL_V2 = 'sslv2';
	const TRANSPORT_SSL_V3 = 'sslv3';
	const TRANSPORT_TLS = 'tls';
	
	/**
	 * Construct
	 *
	 * @param array $config
	 * @return Nette\Mail\SmtpMailer
	 * @throws InvalidArgumentException
	 */
	public function __construct(array $config = NULL)
	{
		$this->state = self::STATE_DISCONNECTED;

		$port = ini_get('smtp_port');
		$this->config = (array)Environment::getConfig('mailer', array(
			'host' => ini_get('SMTP'),
			'port' => is_null($port) ? 25 : $port,
			'username' => NULL,
			'password' => NULL,
			'timeout' => 20,
			'transport' => self::TRANSPORT_TCP
		));
		
		if (!is_null($config))
			$this->config = array_merge($this->config, $config);

		if (!isset($this->config['timeout']) || is_null($this->config['timeout']))
			$this->config['timeout'] = 20;

		if (!in_array($this->config['transport'], stream_get_transports()))
			throw new InvalidArgumentException("Invalid transport type '{$this->config['transport']}'. Support only " . implode(',', stream_get_transports()));
	}

	/**
	 * Is server connection opened
	 *
	 * @return bool
	 */
	final protected function isConnectionOpen()
	{
		return !is_null($this->connection);
	}

	/**
	 * Connect to mail smtp server
	 */
	protected function openConnection()
	{
		$this->connection = @fsockopen(
				$this->config['transport'] . '://' . $this->config['host'],
				$this->config['port'],
				$errorNumber,
				$errorMessage,
				$this->config['timeout']
		);

		if ($errorNumber)
			throw new IOException($errorMessage, $errorNumber);

		if ($this->connection !== FALSE)
			return;

		if (!strncasecmp(PHP_OS, 'win', 3))
			socket_set_timeout($this->connection, $this->config['timeout'], 0);
	}

	/**
	 * Ger server response by command
	 *
	 * @param string|array $command
	 * @return stdClass
	 * @throws IOException
	 */
	protected function getResponse($command = NULL)
	{
		if (!$this->isConnectionOpen())
			$this->openConnection();

		if (!is_null($command)) {
			foreach ((array)$command as $line) {
				if (@fwrite($this->connection, $line . Mail::EOL) === FALSE)
					throw new IOException("Could not send command '$line' to server.");
			}
		}

		$response = (object) array('code' => NULL, 'text' => NULL);
		while ($line = fgets($this->connection, self::MAX_RESPONSE_LENGTH)) {
			$line = rtrim($line);
			if (strlen($line) < 3)
				break;

			$response->code = substr($line, 0, 3);
			$response->text = substr($line, 4);
			
			if (substr($line, 3, 1) == ' ')
				break;
		}

		return $this->response = $response;
	}

	/**
	 * Is connected
	 * 
	 * @return bool
	 */
	final protected function isConnected()
	{
		return $this->state == self::STATE_CONNECTED ? TRUE : FALSE;
	}

	/**
	 * Connect to server
	 *
	 * @throws InvalidStateException
	 */
	protected function connect()
	{
		if (!$this->isConnected()) {
			$response = $this->getResponse();
			if ($response->code != 220) {
				throw new InvalidStateException(
					"Invalid initial server response. Server response '{$response->code} {$response->text}'"
				);
			}

			$response = $this->getResponse("EHLO " . $_SERVER['SERVER_NAME']);
			if ($response->code != 250) {
				$response = $this->getResponse("HELO " . $_SERVER['SERVER_NAME']);
				if ($response->code != 250) {
					throw new InvalidStateException(
						"Server not accepted EHLO/HELO. Server response '{$response->code} {$response->text}'"
					);
				}
			}

			if (!is_null($this->config['username']))
				$this->authenticate();

			$this->state = self::STATE_CONNECTED;
		}
	}

	/**
	 * Authenticate
	 *
	 * @throws InvalidStateException
	 */
	protected function authenticate()
	{
		if ($this->config['transport'] == self::TRANSPORT_TLS) {
			$response = $this->getResponse("STARTTLS");
			if ($response->code != 220 || !stream_socket_enable_crypto($this->connection, TRUE, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
				throw new InvalidStateException(
					"Server not accepted TLS. Server response '{$response->code} {$response->text}'"
				);
			}
		}

		$response = $this->getResponse("AUTH LOGIN");
		if ($response->code != 334) {
			throw new InvalidStateException(
				"Server not accepted authentication. Server response '{$response->code} {$response->text}'"
			);
		}

		$response = $this->getResponse(base64_encode($this->config['username']));
		if ($response->code != 334) {
			throw new InvalidStateException(
				"Server not accepted authentication username. Server response '{$response->code} {$response->text}'"
			);
		}

		$response = $this->getResponse(base64_encode($this->config['password']));
		if ($response->code != 235) {
			throw new InvalidStateException(
				"Server not accepted authentication password. Server response '{$response->code} {$response->text}'"
			);
		}
	}

	/**
	 * Sends e-mail.
	 * 
	 * @param Nette\Mail\Mail $mail
	 * @throws IOException
	 * @throws InvalidStateException
	 */
	public function send(Mail $mail)
	{
		if (!$this->isConnected())
			$this->connect();

		$data = $mail->generateMessage();
			
		list($from) = array_keys($mail->headers['From']);
		$this->setFrom($from);
		
		$mails = array();
		if (isset($mail->headers['To']) && count($mail->headers['To']) > 0) {
			foreach (array_keys($mail->headers['To']) as $adress)
				$this->addTo($adress);
		}
		if (isset($mail->headers['Cc']) && count($mail->headers['Cc']) > 0) {
			foreach (array_keys($mail->headers['Cc']) as $adress)
				$this->addTo($adress);
		}
		if (isset($mail->headers['Bcc']) && count($mail->headers['Bcc']) > 0) {
			foreach (array_keys($mail->headers['Bcc']) as $adress)
				$this->addTo($adress);
		}
		
		$this->sendData($data);

		$this->close();
	}
	
	/**
	 * Set from adress
	 * 
	 * @param string $mail
	 * @throws InvalidStateException
	 */
	protected function setFrom($mail)
	{
		$response = $this->getResponse("MAIL FROM:<".$mail.">");
		
		if ($response->code != 250) {
			throw new InvalidStateException(
				"Server not accepted MAIL FROM. Server response '{$response->code} {$response->text}'"
			);
		}
	}
	
	/**
	 * Add for adress
	 * 
	 * @param string $mail
	 * @throws InvalidStateException
	 */
	protected function addTo($mail)
	{
		$response = $this->getResponse("RCPT TO:<".$mail.">");
		
		if ($response->code != 250)
			throw new InvalidStateException("Server not accepted RCPT. Server response '{$response->code} {$response->text}'");
	}
	
	/**
	 * Send data
	 * 
	 * @param string $data
	 * @throws InvalidArgumentException
	 */
	protected function sendData($data)
	{
		$response = $this->getResponse("DATA");
		if ($response->code != 354)
			throw new InvalidStateException("Server not accepted DATA. Server response '{$response->code} {$response->text}'");

		$response = $this->getResponse(array_merge(explode("\n", str_replace(Mail::EOL, "\n", $data)), array(Mail::EOL . ".")));
		if ($response->code != 250)
			throw new InvalidStateException("Unable to send email. Server response '{$response->code} {$response->text}'");
	}

	/**
	 * Close connection
	 *
	 * @throws InvalidStateException
	 */
	protected function close()
	{
		if ($this->isConnected()) {
			$response = $this->getResponse("quit");
			if ($response->code != 221) {
				throw new InvalidStateException(
					"Server not accepted quit. Server response '{$response->code} {$response->text}'"
				);
			}

			$this->state = self::STATE_DISCONNECTED;
		}

		if ($this->isConnectionOpen()) {
			fclose($this->connection);
			$this->connection = NULL;
		}
	}

	/**
	 * Disconect before destruct
	 *
	 * @throws InvalidStateException
	 */
	public function __destruct()
	{
		$this->close();
	}
}