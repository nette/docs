<?php

define('APP_DIR', dirname(__FILE__) . '/../app');
define('LIBS_DIR', dirname(__FILE__) . '/../libs');

require dirname(__FILE__).'/../app/bootstrap.db.php';
$cli = new Doctrine_Cli(Environment::getVariable('doctrine_config'));
$cli->run($_SERVER['argv']);

