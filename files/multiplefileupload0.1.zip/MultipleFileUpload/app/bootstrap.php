<?php


MultipleFileUpload::register();