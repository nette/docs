<?php

namespace Exchange;

use Utility\CUrl;

require_once __DIR__ .'/ICnb.php';

/**
 * PHP > 5.3
 *
 * @author Milan Matějček
 * @since 2009-06-22 - version 0.5
 * @version 2.3
 */
abstract class Cnb implements ICnb
{
    /**
     * setup for proxy
     * this variable use Cnb::setProxy() for CUrl
     * http://www.php.net/manual/en/function.curl-setopt.php
     * @var string
     */
    static public $proxyName = NULL;
    static public $proxyPort = 0;
    static public $proxyAuth = NULL;


    /**
     * number of version
     * @var string
     */
    static private $version = FALSE;

    /**
     * key from array $this->rating
     */
    const RATE      ='rate';
    const NUM_FORMAT='format';
    const DECIMAL   ='decimal';
    const DEC_POINT ='decpoint';
    const THOUSANDS ='thousands';
    const SYMBOL    ='symbol';
    const CODE      =FALSE;
    const STATUS    =FALSE;
    const COUNTRY   =FALSE;//only czech
    const NAME      =FALSE;//only czech
    const FROM1     =FALSE;
    const TO        =FALSE;

    /**
     * name of cache file and name of static class
     * @var const string
     */
    const RATE_CLASS ='ExchangeRate';

    /**
     * explicit formating number for rating, use UPPERCASE key in array
     * @var array
     */
    public static $defineMoney = array(
                                    'CZK'=>array('1 Kč', 0, ',', ' '),
                                    'EUR'=>array('1€', 2, ',', '.'),
                                    'USD'=>array('$1', 2, '.', ','),
                                    'GBP'=>array('£1', 2, '.', ''),
                                    'PLN'=>'1 Zł',///load default formating
                                    );

    /**
     * class for history
     * @var string
     */
    protected $actualClass = Cnb::RATE_CLASS;

    /**
     * load both list of currency
     * @var bool - FALSE download only Cnb::CNB_DAY
     */
    protected $loadBoth = TRUE;

    /**
     * default number format
     * @var array
     */
    protected $defaultFormat = array(2, ',', ' ');

    /**
     * corection for rating, up or down [%], for czech eshop is recommended 1.03 is different beetwen buy and middle rate
     * @example 5% = 1.05, -5% = 0.95
     * recommended is by calculate 1.035 rounded to 1.04
     * correction works well when default is CZK, eur to eur, eur to czk, czk to eur
     * @var number
     */
    protected $correction = 1;

    /**
     * define case size of code, 0-lowercase, 1-uppercase, another int-Firstletter
     * @var int
     */
    protected $fontSize = 1;

    /**
     * time for reload cache [s]
     * @var int
     */
    protected $refresh = 86400;

    /**
     * namespace session in Nette
     * @var string
     */
    protected $sessionName = 'ExchangeRate';

    /**
     * letter corection by str_replace
     * @var array
     */
    protected $rFound = array(1, ' ');
    protected $rChange = array('', "\xc2\xa0");

    /**
     * default money on web, must be UPPER
     * @var string
     */
    protected $defMoney = 'CZK';

    /**
     * show actual money for web and is first in array $this->rating
     * @var string
     */
    protected $webMoney;

    /**
     * saved letter size
     * @var function
     */
    protected $strTo;

    /**
     * vat, only prefered value [%]
     * @example 20% = 1.20
     * @var real
     */
    protected $vat = 1.2;

    /**
     * method self::format() return price with vat if set on TRUE
     * @var bool
     */
    protected $globalVat = FALSE;

    /**
     * last working value
     * @var array
     */
    protected $lastChange = array(null, null);

    /**
     * rating list
     * @var array
     */
    protected $rating = array();

    /**
     * path to cache file
     * @var string
     */
    private $cacheFile = null;

    /**
     * nastavuje co se bude a nebude stahovat
     * @var array
     */
    private $property = array();

    /**
     * make all setup
     * @param string  set output currency
     * @param boolean set global vat
     * @return void
     */
    public function __construct($webMoney=0, $globalVat=FALSE)
    {
        $this->setGlobalVat($globalVat);
        $this->strTo = self::strTo($this->fontSize);
        $this->loadList();
        $this->setWebMoney($webMoney);
        self::clearDefineMoney();
        unset($this->defaultFormat, $this->loadBoth, $this->refresh,
                $this->fontSize, $this->sessionName);
    }

    /**
     * is fast getter for information, name for function is same as value of constant upper
     * @example $this->getDecPoint('eur');
     * @param $name value of constant
     * @param $args currency
     * @return mixed
     */
    public function __call($name, $args)
    {
        $args = (!empty($args))? $args[0]: FALSE;

        $name = strtolower($name);

        if(substr($name, 0, 3) == 'get')
        {
            $name = substr($name, 3);
        }

        $val = $this->getMoney($args, $name);

        if(empty($val))
        {
           throw new \MemberAccessException('This is not value of constant in this class "'. $name .'"!');
        }

        return $val;
    }

    /**
     * return value of $this->$rating array, you can see __call()
     * @param string $code currency
     * @param string $key use value of constant upper, rate, code
     * @return mix
     */
    public function getMoney($code=FALSE, $key=FALSE)
    {
        $code = $code? $this->loadCurrency($code): $this->webMoney;

        if($key === FALSE)
        {
            return $this->rating[$code];
        }

        return $this->rating[$code][$key];
    }

    /**
     * actual currency of output for web
     * @return string
     */
    public function getWebMoney()
    {
        return $this->webMoney;
    }

    /**
     * default currency
     * @return string
     */
    public function getDefMoney()
    {
        return $this->defMoney;
    }

    /**
     * all currency for use
     * @return array
     */
    abstract public function & getAllCode($codeSort=FALSE);

    /**
     * load new currency for use
     * @params string ... code of currency
     * @return string the first code of list
     */
    abstract public function loadCurrency(/* ... */);

    /**
     * currency list
     * @param string ... [arg1, arg2 OR array(arg1, arg2, ...) OR bool] -code of currency
     * @return array
     */
    public function & getRating()
    {
        $args = func_get_args();

        if(empty($args))
        {
            $args = self::$defineMoney;
        }
        elseif($args[0] === TRUE)
        {
            return $this->rating;
        }
        elseif($args[0] === FALSE)
        {
            $args = $this->getAllCode();
        }
        elseif(is_array($args[0]))
        {
            $args = $args[0];
        }

        $this->loadCurrency($args);

        return $this->rating;
    }

    /**
     * date of last download cache file
     * @param string $format -for format used function date()
     * @return date|timestamp
     */
    public function getDate($format=FALSE)
    {
        $time = filemtime($this->getActualFile());

        if($format != FALSE)
        {
            $time = date($format, $time);
        }

        return $time;
    }

    /**
     * value prefered vat [%]
     * @return real
     */
    public function getVat()
    {
        return ($this->vat * 100)-100;
    }

    /**
     * compare with output currency
     * @param $code code of currency, careful case sensitivity
     * @return boolean
     */
    public function isActual($code)
    {
        return ($code == $this->webMoney);
    }

    /**
     * global vat is eneble
     * @return bool
     */
    public function isVatEnable()
    {
        return $this->globalVat;
    }

    /**
     * transfer number by exchange rate
     * @param double|int|string $price number
     * @param string $from default currency
     * @param string $to output currency
     * @param int $round number round
     * @return double
     */
    public function change($price, $from=FALSE, $to=FALSE, $round=FALSE)
    {
        if(is_string($price))
        {
            $price = (double)self::stroke2point($price);
        }

        $from = (!$from)? $this->defMoney: $this->loadCurrency($from);

        $to = (!$to)? $this->webMoney: $this->loadCurrency($to);

        $r = $this->getCalculationRate();
        $price =$this->rating[$to][$r] / $this->rating[$from][$r] * $price;

        if($round !== FALSE)
        {
            $price =round($price, $round);
        }

        return $price;
    }

    /**
     * count, format price and set vat
     * @param $number int|double|string price
     * @param $from string|bool TRUE currency doesn't counting, FALSE set actual
     * @param $to string output currency, FALSE set actual
     * @param $vat bool|real use vat, but get vat by method $this->formatVat(), look at to globatVat upper
     * @return number string
     */
    public function format($number, $from=FALSE, $to=FALSE, $vat=FALSE)
    {
        if($to != FALSE)
        {
            $old = $this->webMoney;
            $to = $this->loadCurrency($to);
            $this->webMoney =$to;
        }

        if($from !== TRUE)
        {
            $number = $this->change($number, $from, $to);
        }

        $getVat = FALSE;
        if($vat === FALSE)
        {
            $vat = $this->vat;
        }
        elseif($vat === TRUE)
        {
            $getVat = TRUE;
            $vat = $this->vat;
        }
        else
        {
            $vat = (double)$vat;
        }

        $withVat = $number * $vat;

        if($this->globalVat || $getVat)
        {
            $number = $withVat;
        }

        $number = $this->numberFormating($number, $this->webMoney);

        if($to != FALSE)
        {
            $this->webMoney = $old;
        }
        else
        {
            $to = $this->webMoney;
        }

        $this->lastChange = array($withVat, $to);

        return $number;
    }

    /**
     * before call this method MUST call method format()
     * formating price only with vat
     * @return string
     */
    public function formatVat()
    {
        return $this->numberFormating($this->lastChange[0], $this->lastChange[1]);
    }

    /**
     * delete cache file
     * @return bool
     */
    public function deleteTemp()
    {
        $new = $this->getActualFile();
        return self::rename($new, $this->getOldFile($new));
    }

    /**
     * ve vyvoji
     * @deprecated
     * @param $key
     */
//    public function sort($key)
//    {
//        if(!isset($this->rating[$this->webMoney][$key]))
//            return FALSE;
//        $tmp = array();
//        foreach($this->rating as &$ma)
//            $tmp[] = &$ma[$key];
//        array_multisort($tmp, $this->rating);
//
//        return $tmp;
//    }


    /**
     * download new currency
     * @return void
     */
    abstract protected function loadList();

    /**
     * create cache file
     * @param string $cnb
     * @param $file name of cache file
     * @return void
     */
    abstract protected function createCache($cnb, $file);

    /**
     * actual cache file
     * @return string
     */
    protected function getActualFile($postFix=null)
    {
        if($this->cacheFile === null || $postFix !== null)
            $this->cacheFile = $this->getTemp() . DIRECTORY_SEPARATOR . $this->actualClass . $postFix . '.php';

        return $this->cacheFile;
    }

    /**
     * path to backup cache file
     * @return string
     */
    protected function getOldFile($actualFile)
    {
        return $actualFile .'.txt';
    }

    /**
     * calculation rate
     * @return string
     */
    protected function getCalculationRate()
    {
        return self::RATE;
    }

    /**
     * path of temp
     * @return string
     */
    protected function getTemp()
    {
        return '.';
    }

    /**
     * setup session for global vat
     * @param bool $vat TRUE|FALSE|null
     * @return void
     */
    protected function setGlobalVat($vat)
    {
        $this->globalVat    =$vat;
    }

    /**
     * create symbol of currency
     * @param string $string
     * @return string
     */
    protected function setSymbol($string)
    {
        return str_replace($this->rFound, '', $string);
    }

    /**
     * setup currency for web and session
     * @param string $code
     * @return void
     */
    protected function setWebMoney($code=FALSE)
    {
        if($code)
        {
            $code = $this->loadCurrency($code);
            $_SESSION[$this->sessionName]  =$code;
        }
        else
        {
            $code =(isset($_SESSION[$this->sessionName]))? $_SESSION[$this->sessionName]: $this->defMoney;
        }

        $this->webMoney = $code;
    }

    /**
     * without session
     */
//    protected function setWebMoney($code=FALSE)
//    {
//        $this->webMoney =($code == FALSE)? $this->defMoney: $this->loadCurrency($code);
//    }

    /**
     * environment TRUE is production
     * @return bool
     */
    protected function isProduction()
    {
        return TRUE;
    }

    /**
     * setup number formating for later use
     * @param string $code -UPPERCASE code
     * @return array
     */
    protected function createFormat($code)
    {
        $strTo      =$this->strTo;
        $numFormat  =array('1 '. $strTo($code));

        if(!isset(self::$defineMoney[ $code ]))
        {//neexistuje vubec nic
            $numFormat =array_merge($numFormat, $this->defaultFormat);
        }
        elseif(is_array(self::$defineMoney[ $code ]))
        {//formatovani existuje
            $numFormat  =self::$defineMoney[ $code ];
        }
        else
        {
            $numFormat[0] =self::$defineMoney[ $code ];
            $numFormat    =array_merge($numFormat, $this->defaultFormat);
        }
        $numFormat[4] = $this->setSymbol($numFormat[0]);
        return array_combine(array(self::NUM_FORMAT, self::DECIMAL, self::DEC_POINT, self::THOUSANDS, self::SYMBOL), $numFormat);
        
        return $numFormat;
    }

    /**
     * formating number
     * @param real $number
     * @return string
     */
    protected function numberFormating($number, $to)
    {
        $this->rChange[0] = number_format($number,
            $this->rating[$to][self::DECIMAL],
            $this->rating[$to][self::DEC_POINT],
            $this->rating[$to][self::THOUSANDS]);
        return str_replace($this->rFound, $this->rChange, $this->rating[$to][ self::NUM_FORMAT ]);
    }

    /**
     * letter size
     * @param int $case
     * @return function|string
     * @deprecated
     */
    static protected function strTo($case=0)
    {
        switch($case)
        {
            case 0:
                return 'strtolower';

            case 1:
                return 'strtoupper';

            default:
                return create_function('$input', 'return strtoupper($input[0]) . strtolower(substr($input, 1));');
        }
    }

    /**
     * property of Cnb
     * @return array
     */
    protected function & getProperty()
    {
        if(empty($this->property))
        {
            $obj    = new \ReflectionClass($this);
            $this->property = array(
                    'COUNTRY' => $obj->getConstant('COUNTRY'),
                    'NAME'    => $obj->getConstant('NAME'),
                    'FROM1'   => $obj->getConstant('FROM1'),
                    'CODE'    => $obj->getConstant('CODE'),
                    'TO'      => $obj->getConstant('TO'),
                    'STATUS'  => $obj->getConstant('STATUS'),);
        }
        return $this->property;
    }

    /**
     * source where can download
     * @return string
     */
    protected function getSource1()
    {
        return ICnb::CNB_DAY;
    }

    /**
     * @return string
     */
    protected function getSource2()
    {
        return ICnb::CNB_DAY2;
    }

    /**
     * setup of proxy
     * @param CUrl $curl
     */
    protected function setProxy(CUrl $curl)
    {
        if(self::$proxyName !== NULL)
        {
            $curl->setOptions(array(
                CURLOPT_PROXY => self::$proxyName,
                CURLOPT_PROXYPORT => self::$proxyPort,
                CURLOPT_PROXYUSERPWD => self::$proxyAuth,
            ));
        }
    }

    /**
     * version of this class
     * @return string
     */
    static public function getVersion()
    {
        if(self::$version === FALSE)
        {
            $rc = new \ReflectionClass(__CLASS__);
            $found = array();
            preg_match('~@version (.*)~', $rc->getDocComment(), $array);
            self::$version = $array[1];
        }
        return self::$version;
    }

    /**
     * safe rename file
     * @param string $new
     * @param string $old
     * @return bool
     */
    static protected function rename($new, $old)
    {
        if(file_exists($new))
        {
            if(file_exists($old))
                unlink($old);
            return rename($new, $old);
        }
        return null;
    }

    /**
     * replace stroke to point
     * @param string $string
     * @return string
     */
    static protected function stroke2point($string)
    {
        return str_replace(',', '.', $string);
    }

    /**
     * define of currency is used only when download currency list
     * @return void
     */
    static protected function clearDefineMoney()
    {
        self::$defineMoney = array_keys(self::$defineMoney);
    }
}
