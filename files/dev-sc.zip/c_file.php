<?php

class c_file extends Object
{
    /*
     * $array_dir    -type: array
     * $prava        -type: array =nastavi se prava se stejnym klicem jako v predchozi $array_dir
     *                 -type: string=pro vsechny slozky v poly budou nastavena stejna prava
        */
    const DS    =DIRECTORY_SEPARATOR;

    public $fopen;
    public $zapis;
    static public $size    =0;
    static public $search  =array('č', 'ď', 'ň', 'ř', 'š', 'ť', 'ž', 'á',
                            'é', 'ě', 'í', 'ó', 'ů', 'ú', 'ý', 'Č', 'Ď', 'Ň', 'Ř',
                            'Š', 'Ť', 'Ž', 'Á', 'É', 'Ě', 'Í', 'Ó', 'Ů', 'Ú', 'Ý',
                            '?');

    static public $change  =array('c', 'd', 'n', 'r', 's', 't', 'z', 'a',
                            'e', 'e', 'i', 'o', 'u', 'u', 'y', 'C', 'D', 'N', 'R',
                            'S', 'T', 'Z', 'A', 'E', 'E', 'I', 'O', 'U', 'U', 'Y',
                            '');

    public function __construct($soubor, $prava='r')
    {
        $this->fopen    =@fopen($soubor, $prava);

        if($this->fopen == false)
        {
            throw new InvalidStateException('This file "'. $soubor .'" did not open.');
        }
    }

    public function close()
    {
        if($this->fopen == true)
        {
            @fclose($this->fopen);//zakomentovano, kdyby byla otevrena url tak to bude zlobit
        }
    }

    public function __destruct()
    {
        $this->close();
    }

    public function write($text, $length=null)
    {
        return fwrite($this->fopen, $text, $length);
    }

    public function seek($from, $to=SEEK_END)
    {
        return fseek($this->fopen, $from, $to);
    }

    public function read($length)
    {
        return fread($this->fopen, $length);
    }

    /**
     * funkce overuje zda je slozka zapisovatelna a kdyztak vytvori slozsku s pravy 777
     *
     * @return void
     */
    static public function isWritable()
    {
        $dir    =func_get_args();

        foreach($dir as $value)
        {
            if(!file_exists($value))
            {
                umask(0000);
                mkdir($value, 0777);
            }
            elseif(!is_writable($value))
            {
                echo 'slozce '.$value.' musis nastavit pravo 777';
                exit;
            }
        }
    }

    /**
     *
     * @param $path
     * @param bool $addSlash
     * @return string
     */
    static public function lastSlash($path, $addSlash=true, $realpath=true)
    {
        $real   =realpath($path);
        if($realpath === true && $real == true)
        {
            $path   =$real;
        }
        else
        {
            $path   =rtrim($path, '\/');
        }

        if($addSlash === true)
        {
            $path   .=self::DS;
        }

        return $path;
    }

    /**
     *
     * @param $file     -dir and file name
     * @param $second   -time second
     * @return bool
     */
    static function oldFiles( $file, $second=86400 )
    {
        return (!file_exists( $file ) || (time() - @filemtime( $file ) > $second));
    }


    /**
     * alias k funkci scandir()
     * @param $path
     * @param bool|string $file -regular string for preg_match
     * @param bool|string $folder   -regular string for preg_match
     * @return array
     */
    static public function scandir($path='./', $file=true, $folder=true)
    {
        $path   =self::lastSlash($path);
        $a      =scandir($path);
        unset($a[0], $a[1]);

        if($file === false && $folder === false)
        {
            return $a;
        }

        $dirs   =array();
        $files  =array();

        foreach($a as $val)
        {
            $isDir  =is_dir($path . $val);
            if($isDir && $folder == true)
            {
                self::addAward($dirs, $folder, $val);
            }
            else if(!$isDir && $file == true)
            {
                self::addAward($files, $file, $val);
            }
        }

        if($file === false)
        {
            return $dirs;
        }
        else if($folder === false)
        {
            return $files;
        }

        return array('dir'=>$dirs, 'file'=>$files);
    }

    /**
     * metoda se vaze na scandir
     * @param array $return
     * @param reg string $way
     * @param string $dir
     * @return void
     */
    static private function addAward(&$array, $way, $fileName)
    {
        if($way === true || preg_match($way, $fileName))
        {
            $array[]    =$fileName;
        }
    }

    static public function dirTime($dir, $date=NULL)
    {
        $handle    =opendir($dir);
        $i=0;
        $x=null;
        if($handle == TRUE){

            while (false !== ($file = readdir($handle)))
            {
                if ($file != "." && $file != ".." )
                {
                    $in =$dir . $file . self::DS;//cesta k souboru ci slozce

                    $f_m_time    =filemtime($in);

                    if(is_dir($in)){

                        $a[$file] =self::f_dir_time($in, $date);

                    }
                    elseif( $x < $f_m_time)
                    {

                        $x =$f_m_time;
                        $y =$file;
                    }
                }
                $i++;
            }

            if(!empty($x)){
                if($date == NULL){
                    $a[$y]  =$x;
                }else{
                    $a[$y] =date($date, $x);
                }
            }
            closedir($handle);
        }
        return $a;
    }

    static public function fileSizeTree($dir='./', $size=0){
        $dirs   =array();
        $dirs[0]  =0;
        $handle    =opendir($dir);

        if($handle    == true)
        {
            while(false !== ($file = readdir($handle)))
            {
                if ($file != '.' && $file != '..' )
                {
                    $in =$dir . $file;

                    if(is_dir($in))
                    {
                        $dirs['_' . $file] =self::fileSizeTree($in . self::DS);
                    }
                    else
                    {//1048576
                        $sizeF  =filesize($in);

                        if($sizeF/1048576 > 3)
                        $dirs[$file] =$sizeF;
                    }
                }
            }

            $dirs[0]  =@array_sum($dirs);

            closedir($handle);
        }

        return $dirs;
    }

    public function prepocet($int)
    {
        while($int >= 1024)
        {
            $int /=1024;
        }

        return $int;
    }

    /**
     * funkce vytvori nazev souboru nebo souboru nebo ostrani hacky carky mezery
     *
     * @version 6.3.2009
     * @param string|array $fileName   -stary nazev souboru
     * @param string|bool  $name       -true=vytvori nahodny nazev, false=upravy stary pro pouziti pro web, string=novy nazev
     * @param int          $maxLennght -maximalni delka retezce
     * @return string|array
     */

    static public function createFileName($fileName, $name=true, $webName=true, $rename=false)
    {
        foreach ((array)$fileName as $key => $fileN)
        {
            $fileName[$key]  =self::createFileNameSingle($fileN, $name, $webName, $rename);
        }

        return $fileName;
    }

    static public function autoUTF($s)
    {
        // detect UTF-8
        if (preg_match('#[\x80-\x{1FF}\x{2000}-\x{3FFF}]#u', $s))
        return $s;

        // detect WINDOWS-1250
        if (preg_match('#[\x7F-\x9F\xBC]#', $s))
        return iconv('WINDOWS-1250', 'UTF-8', $s);

        // assume ISO-8859-2
        return iconv('ISO-8859-2', 'UTF-8', $s);
    }

    /**
     * pro prejmenovani jednoho souboru s kontrolou pouzij createFileName();
     * potom bude fungovat
     */
    static public function createFileNameSingle($fileN, $name=true, $webName=true, $rename=false)
    {
        //$fileN      =self::autoUTF($fileN);
        $oldName    =$fileN;
        $koncovka   =self::fileType($fileN);
        $dir        =dirname($fileN) . self::DS;

        if($name === false)
        {
            $fileName =c_form::md5Hash() . $koncovka;
        }
        else
        {
            if($webName === true)
            {
                $fileN  =strtolower($fileN);
                $search =array_merge(self::$search, array('-', ' ', ','));
                $change =array_merge(self::$change, array('_', '_', ''));
            }
            else
            {
                $search =self::$search;
                $change =self::$change;
            }

            if($name === true)
            {
                $name   =$fileN;
            }

            $name   =str_replace($search, $change, $name);
            $name   =trim($name);

            $fileName =$name . $koncovka;
        }

        if($rename !== false)
        {
            return rename($oldName, $dir . $fileName);
        }

        return $fileName;
    }

    /**
     * vrati koncovku souboru
     * @param $fileName
     * @param bool $cut -koncovku souboru je mozne useknout
     * @param $point    -pridani moznych znaku jako .
     * @return string
     */
    static public function fileType(&$fileName, $cut=true, $point='.')
    {
        $nameArray  =explode('.', strtolower($fileName));

        $zkr        =end($nameArray);

        if($cut === true)
        {
            $fileName   =substr($fileName, 0, -1 * (strlen($zkr) + 1 ));
        }

        return $point . $zkr;
    }

    /**
     * Control file name and if exists make a new random name
     * @version 6.3.2009
     * @param string       $oldName
     * @param string       $newName
     * @return bool
     */
    static public function controlRenameSingle($oldName, $newName)
    {
        $rename    =false;
        if(file_exists($oldName))
        {
            $rename   =rename($oldName, $newName);
        }

        return $rename;
    }

    /**
     * if first and second params are array must same keys
     *
     * @version 6.3.2009
     * @param string|array     $oldName    -old file name one or array
     * @param string|array     $newName    -new file name one or array
     * @return string|array|int    -int = -1 it is arrays haven't same keys
     */
    static public function controlRename($oldName, $newName)
    {
        $is_array_old =is_array($oldName);
        $is_array_new =is_array($newName);
        $result   =false;

        if( $is_array_old && $is_array_new )
        {
            foreach ($oldName as $key => $value)
            {
                $result[$key]   =self::controlRenameSingle($value, $newName[$key]);
            }
        }
        else if(!$is_array_new && !$is_array_old)
        {
            $result  =self::controlRenameSingle($oldName, $newName);
        }

        return $result;
    }

    static public function deleteFiles($dir='./', $search='.svn', $delete=false)
    {
        $dir    =self::lastSlash($dir);
        $handle    =opendir($dir);

        if($handle    !== false)
        {
            while (false !== ($file = readdir($handle)))
            {
                if($file != '.' && $file != '..')
                {
                    $slozka    =$dir . self::DS . $file;
                    $is_dir =is_dir($slozka);

                    if( !preg_match($search, $file) && $is_dir === false)
                    {
                        self::$size    +=filesize($slozka);

                        if($delete === true)
                        unlink($slozka);
                    }
                    elseif($is_dir === true)
                    {
                        self::deleteFiles($slozka, $search, $delete);
                    }
                }
            }

            closedir($handle);
        }
    }
}


