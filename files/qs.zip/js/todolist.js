$(function() {
	afterAjax({});

	$('.ajax').live('click', function(event) {
		event.preventDefault();
		$.get(this.href);
		$("#ajax-spinner, #overbody").each(function() {
			$(this).show();
		});
	});

	$('.ajaxform :submit').live('click', function(event) {
		event.preventDefault();
		$(this).ajaxSubmit();
		$("#ajax-spinner, #overbody").each(function() {
			$(this).show();
		});
	});

	$('<div id="ajax-spinner"></div><div id="overbody"></div>').each(function() {
		$(this).appendTo("body").ajaxStop(function() {
			$(this).hide();
		}).hide();
	});
});

jQuery.ajaxSetup({
	success: afterAjax
});

function afterAjax(payload) {
	$.nette.success.call($.nette, payload);
	$('.todo-row').draggable({
		'helper':'clone',
		'opacity':0.7
	});
}