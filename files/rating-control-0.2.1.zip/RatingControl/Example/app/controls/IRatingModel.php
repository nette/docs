<?php

/**
 * IRatingModel interface of RatingControl plugin for Nette
 *
 * @author Radek Ježdík
 * @version 0.1
 * @license New BSD License
 * @package Nette\Extras\RatingControl
 */
interface IRatingModel
{
    /**
     * Returns unique ID for the control (possibly the same as ID of ratable object)
     * @param mixed can be object (article, product, ...) or its ID to rate
     * @return int|string unique ID
     */
    public function getUniqueId($ratable);

    /**
     * Returns true if user already voted, otherwise false
     * @param int   unique ID returned by getUnique
     * @return bool true if user voted, otherwise false
     */
    public function wasVoted($id);

    /**
     * Returns current average rating for the ratable object
     * @param mixed can be object (article, product, ...) or its ID to rate
     * @return float average rating
     */
    public function getRating($ratable);

    /**
     * Returns count of all votes for this ratable
     * @param mixed can be object (article, product, ...) or its ID to rate
     * @return int vote count
     */
    public function getVoteCount($ratable);

    /**
     * Adds new rating, specified by user
     * @param int|string ID returned by getUniqueId method
     * @param int new rating (from 1 to number_of_stars)
     */
    public function addRating($id, $newRating);
}
