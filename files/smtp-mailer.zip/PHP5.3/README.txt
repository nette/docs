SMTP Sendmail Mailer (c) Patrik Votoček (Vrtak-CZ), 2008-2010 (http://patrik.votocek.cz)

Requirements
------------
Nette Framework 0.9.x or higher. (PHP 5.3 edition)

Documentation and Examples
--------------------------
Documentation and examples is available on:

http://addons.nettephp.com/cs/smtpmailer
