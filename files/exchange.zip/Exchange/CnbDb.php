<?php

namespace Exchange;
use Dibi, DibiException, DibiDriverException, Utility\DateTime, Utility\CUrl;

require_once __DIR__ .'/Cnb.php';
require_once __DIR__ .'/ICnbDb.php';

/**
 * @author Hakuna
 */
class CnbDb extends Cnb implements ICnbDB
{
    //protected $refresh = 1;

    const CODE = 'code';

    /**
     * @var DibiConnection
     */
    protected $db;

    /**
     * @var DateTime
     */
    protected $date = 0;

    /**
     * download sql
     * @var string
     */
    protected $sql = null;

    /**
     * only for first update
     * @var bool
     */
    private $update = false;

    public function __construct($webMoney=0, $globaVat=false, $date='NOW', $connection=0)
    {
        $this->db = dibi::getConnection($connection);
        $this->db->getDriver()->registerFunction('correction', array($this, 'correction'), 2);
        $this->date = new DateTime($date);
        $this->getActualFile($this->date->format('Y'));
        parent::__construct($webMoney, $globaVat);
    }

    /**
     * this method is registred for sqLite3
     * @param tring $code
     * @param int $rate
     * @return float
     */
    public function correction($code, $rate)
    {
        if($rate === NULL)
            $rate = 1;
        return $this->defMoney == $code? $rate: $rate/$this->correction;
    }

    /**
     * @deprecated
     * @param inr $year
     */
    public function downloadYear($year='this')
    {
        if($year === 'this')
            $year = $this->date->forma('Y');
        
        if(file_exists($this->getActualFile($year)))
            return true;
    }

//-----------------download actual rating list----------------------------------
    /**
     * download and prepare cache
     */
    protected function loadList()
    {
        $new    =$this->getActualFile();

        $download = false;
        if(!file_exists( $new ) || filesize($this->db->getConfig('database')) < 1)
        {//stahne rocni db
            $yyyy = $this->date->format('Y');
            $download   = self::CNB_YEAR . $yyyy;
            $download2  = self::CNB_YEAR2 . $yyyy;
            CnbDbCreate::createDb($this->db);
        }
        elseif((time() - @filemtime( $new ) > $this->refresh) || $this->update)
        {
            $download = parent::CNB_DAY;
            $download2 = parent::CNB_DAY2;
        }

        if( $download )
        {
            $cnb2   =true;
            if(ini_get('allow_url_fopen') && parent::$proxyName === NULL)
            {
                $cnb    =@file_get_contents($download);
                if($this->loadBoth)
                    $cnb2   =@file_get_contents($download2);
            }
            elseif(extension_loaded('curl'))
            {
                $curl   =new CUrl($download);
                $this->setProxy($curl);
                $cnb    =$curl->getResult();
                if($this->loadBoth)
                {
                    $curl   =new CUrl($download2);
                    $this->setProxy($curl);
                    $cnb2   =$curl->getResult();
                    if(\strlen($cnb2) < 10)
                        $cnb2 = '';
                }
            }
            else
            {
                throw new \RuntimeException('This library need allow_url_fopen -enable or curl extension');
            }

            if( $cnb !== false && $cnb2 !== false )
            {
                $this->createCache(self::stroke2point($cnb . $cnb2), $new);
            }
            else
            {
                //@todo vytvorit kontrolu pres db
                throw new \RuntimeException('You must connect to internet. It can\'t download rating list');
            }
        }
    }


//-----------------methods whose create cache file------------------------------
    /**
     * save source to db and setup control file
     * @param string $cnb
     * @param string $file
     */
    protected function createCache($cnb, $file)
    {
        if($this->isDateLine($cnb))
        {
            $this->createYearCache($cnb);
            file_put_contents($file, '');
            $this->update = true;
            $this->loadList();
        }
        else
        {
            $this->createDayCache($cnb);
            $this->update = false;
            touch($file);
        }
    }

    /**
     * parser for year statistic
     * @param string $cnb
     */
    protected function createYearCache(&$cnb)
    {
        $rows = explode("\n", trim($cnb));
        $dateLine = null;
        foreach($rows as $row)
        {
            if($this->isDateLine($row))
            {
                $dateLine = $this->saveCodeRow($row);
            }
            else
            {
                $this->saveRateRow($row, $dateLine);
            }
        }
    }

    /**
     * parser for day statistics
     * @param string $cnb
     */
    protected function createDayCache(&$cnb)
    {
        $cnb    = explode("\n", trim($cnb));
        $info   = explode(' #', $cnb[0]);
        $cnb[0] = Cnb::CNB_CZK;
        unset($cnb[1]);
        $this->db->begin();

        try {
            $this->db->query('INSERT INTO %n (%n) VALUES (%s)',
                self::T_CNB_HISTORY, self::C_DATE, self::czechDate2Sql($info[0]));
            $idHis = $this->db->getInsertId();
        }catch (DibiDriverException $e)
        {
            if($e->getCode() != 19)
            {
                $this->db->rollback();
                throw $e;
            }
            $idHis = $this->db->query('SELECT %n FROM %n WHERE %n=%s  LIMIT 1',
                     self::C_ID_HISTORY ,self::T_CNB_HISTORY, self::C_DATE, self::czechDate2Sql($info[0]))
                              ->fetchSingle();
        }        
        
        $codes = $this->db->query('SELECT %n, %n FROM %n', self::C_CODE, self::C_ID_CURRENCY, self::T_CNB)->fetchPairs();
        
        foreach($cnb as $key => $val)
        {
            $val = explode(parent::PIPE, $val);

            if( !isset($val[4]) || !is_numeric($val[4]) || ($val[4] = (double)$val[4]) <= 0 )
                continue;
            $numFormat  =$this->createFormat($val[3]);
            
            $data = array(
                    self::C_FORMAT    =>&$numFormat[self::C_FORMAT],
                    self::C_DECIMAL   =>&$numFormat[self::C_DECIMAL],
                    self::C_DECPOINT  =>&$numFormat[self::C_DECPOINT],
                    self::C_THOUSANDS =>&$numFormat[self::C_THOUSANDS],
                    self::C_SYMBOL    =>$this->setSymbol($numFormat[self::C_FORMAT]),
                    self::C_COUNTRY   =>&$val[0],
                    self::C_NAME      =>&$val[1],
                    self::C_FROM      =>&$val[2],
                    self::C_CODE      =>&$val[3],
                );

            if(!isset($codes[$val[3]]))
            {
                $this->db->query('INSERT INTO %n %v', self::T_CNB, $data);
                $id = $this->db->getInsertId();
            }
            else
            {
                $this->db->query('UPDATE %n SET %a WHERE %n=%i', self::T_CNB, $data, self::C_ID_CURRENCY, $codes[$val[3]]);
                $id = $codes[$val[3]];
            }

            //pro CZK
            if($key != 0 && $this->update === false)
            {
                try
                {
                $this->db->query('INSERT INTO %n %v', self::T_CNB_RATE,
                    array(self::C_OID_CURRENCY => $id,
                          self::C_OID_HISTORY => $idHis,
                          self::C_TO => $val[4]));
                }
                catch (DibiDriverException $e)
                {
                    if($e->getCode() != 19)
                    {
                        $this->db->rollback();
                        throw $e;
                    }
                }
            }
        }
        $this->db->commit();
        return true;
    }

    /**
     * save value to table T_CNB
     * @param string $row
     * return array
     */
    protected function saveCodeRow(&$row)
    {
        $dateLine = explode(parent::PIPE, $row);
        unset($dateLine[0]);
        $insert = array(self::C_CODE=>null, self::C_FROM=>null);
        $this->db->begin();

        foreach($dateLine as $key => $val)
        {
            list($insert[self::C_FROM], $insert[self::C_CODE]) = explode(' ', $val);

            try
            {
                $this->db->query('INSERT INTO %n %v', self::T_CNB, $insert);                
                $dateLine[$key] = $this->db->getInsertId();
            }
            catch (DibiException $e)
            {
                if($e->getCode() != 19)
                {
                    $this->db->rollback();
                    throw $e;
                }
                $dateLine[$key] = $this->db->query('SELECT %n FROM %n WHERE %and',
                                self::C_ID_CURRENCY, self::T_CNB, $insert)->fetchSingle();
            }
        }
        $this->db->commit();
        return $dateLine;
    }

    /**
     * save rows to table T_CNB_RATE
     * @param string $row
     * @param array $dateLine
     * @return bool
     */
    protected function saveRateRow(&$row, &$dateLine)
    {
        $rateLine = explode(parent::PIPE, $row);
        $rateLine[0] = array(self::C_DATE=>self::czechDate2Sql($rateLine[0]));
        $this->db->begin();
        
        try {
            //nedavat ignore!!!
            $this->db->query('INSERT INTO %n %v', self::T_CNB_HISTORY, $rateLine[0]);
            $id = $this->db->getInsertId();
        }
        catch(DibiDriverException $e)
        {
            if($e->getCode() != 19)
            {
                $this->db->rollback();
                throw $e;
            }
            $id = $this->db->query('SELECT %n FROM %n WHERE %and',
                       self::C_ID_HISTORY, self::T_CNB_HISTORY, $rateLine[0])
                       ->fetchSingle();
        }

        unset($rateLine[0]);
        $insert = array(self::C_OID_CURRENCY=>0, self::C_OID_HISTORY=>$id, self::C_TO=>0.0);
        foreach ($rateLine as $key => $val)
        {
            $insert[self::C_OID_CURRENCY] = $dateLine[$key];
            $insert[self::C_TO] = (float)$val;
            if($insert[self::C_TO] <= 0)
            {
                $this->db->query('DELETE FROM %n WHERE %and', self::T_CNB, array(self::C_ID_CURRENCY=>$dateLine[$key]));
                continue;
            }
            $this->db->query('INSERT OR IGNORE INTO %n %v', self::T_CNB_RATE, $insert);
        }
        $this->db->commit();
        return true;
    }

//-----------------helper for sql query-----------------------------------------
    /**
     * from CZECH format to ISO
     * @param $date string CZECH FORMAT, DD.MM.YYYY
     * @return date
     */
    static public function czechDate2Sql($date)
    {
        $date   =explode('.', $date);
        return $date[2] .'-'. $date[1] .'-'. $date[0];
    }

    /**
     * check if is line with date for year list
     * @param string $str
     */
    protected function isDateLine(&$str)
    {
        return substr($str, 0, 5) == 'Datum';
    }

    /**
     * array created by defined constatn in class
     * @return array
     */
    protected function getColumn()
    {
        return array_combine( array_keys($this->getProperty()),
            array(self::C_COUNTRY, self::C_NAME, self::C_FROM, self::C_CODE, self::C_TO, self::C_STATUS)
        );
    }

    /**
     * prepare sql column for another use
     * @return string
     */
    protected function getSql()
    {
        if($this->sql === null)
        {
            $property = $this->getProperty();
            $col = $this->getColumn() + array(self::C_FORMAT, self::C_DECIMAL, self::C_DECPOINT, self::C_THOUSANDS, self::C_SYMBOL);

            foreach($col as $key => $val)
            {
                if(isset($property[$key]) && $property[$key] === false)
                    continue;
                $this->sql .= "`$val`, ";
            }
            $this->sql .= 'correction(['. self::C_CODE .'], ['. self::C_RATE .']) AS ['. self::C_RATE .'], '.
                          'IFNULL(['. self::C_DATE .'], DATE(\'now\')) AS ['. self::C_DATE .']';
        }
        return $this->sql;
    }

//-----------------inherit methods----------------------------------------------
    /*
    protected function isProduction()
    {
        return false;
    }
    */

    /**
     * load currency by code
     * @param string $code
     * @param string ...
     */
    public function loadCurrency(/*...*/)
    {
        $args = func_get_args();
        if(empty($args))
           return NULL;
        if(is_array($args[0]))
            $args = $args[0];

        $last = NULL;
        foreach($args as $key => &$val)
        {
            $val = strtoupper($val);
            if(isset($this->rating[$val]))
            {
                $last = $args[$key];
                unset($args[$key]);
            }
        }
        if(empty($args))
            return $last;
        unset($val);// break the reference with the last element
        
        $result = (array)$this->db->query(
            'SELECT '. $this->getSql() .'
            FROM `'. self::T_CNB .'`
            LEFT JOIN `'. self::T_CNB_RATE .'` ON `'. self::C_OID_CURRENCY .'` = `'. self::C_ID_CURRENCY .'`
            LEFT JOIN `'. self::T_CNB_HISTORY .'` ON `'. self::C_OID_HISTORY .'` = `'. self::C_ID_HISTORY .'`
            AND `'. self::C_DATE .'` <= \''. $this->date .'\'
            WHERE `'. self::C_CODE .'` IN %in
            GROUP BY ['. self::C_CODE .']
            ORDER BY ['. self::C_DATE .'] DESC',
            $args)->fetchAssoc(self::C_CODE);
        if($result === false)
            throw new \RangeException('This "'. $code .'" code not found.');

        $this->rating += (array)$result;
        reset($args);
        return current($args);
    }

    /**
     * @deprecated
     * @param string $code
     * @param int $year
     */
    public function drawGraf($code=null, $year=null)
    {
        if($year === null)
            $year = $this->date->format ('Y');
        $from = $year . '-01-01';
        $to   = $year . '-12-31';

        $this->downloadYear($year);

        if($code === null)
            $code = $this->webMoney;
//@TODO dodelat
        pd($from, $to);
        $this->db->query(
            'SELECT * FROM %n', self::T_CNB
                );
    }

    /**
     * @param $codeSort make nothing
     * @return array
     */
    public function & getAllCode($codeSort=TRUE)
    {
        return $this->db->query(
            'SELECT %n
            FROM %n
            ORDER BY %n ASC',
            self::C_CODE,
            self::T_CNB,            
            self::C_CODE)
            ->fetchPairs();
    }
}