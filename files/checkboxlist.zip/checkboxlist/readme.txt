Nette Framework extras - CheckboxList
=====================================

Fork of Nette tool Skeleton with example of using the CheckboxList FormControl.

See: http://addons.nettephp.com/cs/checkboxlist