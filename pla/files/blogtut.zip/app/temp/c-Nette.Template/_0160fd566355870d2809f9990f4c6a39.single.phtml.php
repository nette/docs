<?php //netteCache[01]000242a:2:{s:4:"time";s:21:"0.88055100 1281261299";s:9:"callbacks";a:1:{i:0;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:72:"C:\wamp\www\blogtut\document_root/../app/templates/Homepage/single.phtml";i:2;i:1281259882;}}}?><?php
// file …/templates/Homepage/single.phtml
//

use Nette\Templates\LatteMacros, Nette\Templates\TemplateHelpers, Nette\SmartCachingIterator, Nette\Web\Html, Nette\Templates\SnippetHelper, Nette\Debug, Nette\Environment, Nette\Templates\CachingHelper, Nette\Application\InvalidLinkException;

$_cb = LatteMacros::initRuntime($template, NULL, 'c1b1c548d5'); unset($_extends);


//
// block content
//
if (!function_exists($_cb->blocks['content'][] = '_cbb008fbddaaa_content')) { function _cbb008fbddaaa_content() { extract(func_get_arg(0))
?>
<a href="<?php echo TemplateHelpers::escapeHtml($presenter->link("default")) ?>"><< home </a>
<div class="post">
	<h1><?php echo TemplateHelpers::escapeHtml($post['title']) ?></h1>
	<small>Přidáno <?php echo TemplateHelpers::escapeHtml($template->date($post['date'])) ?></small>
	<p><?php echo TemplateHelpers::escapeHtml($post['body']) ?></p>
</div>
<h3>Komentáře:</h3>
<div id="comments">
<?php foreach ($iterator = $_cb->its[] = new SmartCachingIterator($comments) as $comment): ?>
	<div class="commment">
		<p><?php echo TemplateHelpers::escapeHtml($comment['body']) ?></p>
		<small><?php echo TemplateHelpers::escapeHtml($comment['author']) ?>, <?php echo TemplateHelpers::escapeHtml($template->date($comment['date'])) ?></small>
		<hr>
	</div>
<?php endforeach; array_pop($_cb->its); $iterator = end($_cb->its) ?>
</div>
<?php $control->getWidget("commentForm")->render() ;
}}

//
// end of blocks
//

if ($_cb->extends) { ob_start(); }

if (SnippetHelper::$outputAllowed) {
if (!$_cb->extends) { call_user_func(reset($_cb->blocks['content']), get_defined_vars()); }  
}

if ($_cb->extends) { ob_end_clean(); LatteMacros::includeTemplate($_cb->extends, get_defined_vars(), $template)->render(); }
