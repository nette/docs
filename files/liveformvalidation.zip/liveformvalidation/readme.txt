Live Form Validation Client Script
v0.8

Plugin for Nette Framework, adds support for live validation of Nette/Forms

more information at http://nettephp.com/cs/extras/live-form-validation