<?php
class Guestbook extends Object
{
	/** @var string */
	private $table = 'items';

	/**
	 * @param array $values
	 * @return DibiResult|int
	 */
	public function insert($values)
	{
		if($values['email'] === '')
			$values['email'] = NULL;
		return dibi::query("INSERT INTO %n", $this->table, $values);
	}

	/**
	 * @return array
	 */
	public function fetchAll()
	{
		return dibi::fetchAll("SELECT * FROM %n", $this->table);
	}

	/**
	 * @param int $id
	 * @return DibiResult|NULL
	 */
	public function delete($id)
	{
		return dibi::query("DELETE FROM %n", $this->table, "WHERE [id]=%i", $id);
	}

	/**
	 * @return string
	 */
	public function getTable()
	{
		return $this->table;
	}

	/**
	 * @throws InvalidStateException
	 */
	public function setTable()
	{
		throw new InvalidStateException;
	}
}