﻿<?php
abstract class BasePresenter extends Presenter
{
	public function beforeRender(){
		$this->template->menuItems = array
		(
		 'HomePage:'=>'Domů',
		 'Products:'=>'Produkty',
		 'Contact:'=>'Kontakty'
		 );
	}
	//prepínac zoabrazení šablon
	public $oldLayoutMode = FALSE;
}