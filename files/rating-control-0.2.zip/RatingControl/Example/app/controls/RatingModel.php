<?php

class RatingModel implements IRatingModel
{
    public function addRating($id, $newRating)
    {
        $session = Environment::getSession('rating'.$id);
        $session->wasVoted = true;
        /*dibi::insert('ratings',
                array(
                    'product_id' => $id,
                    'rating' => (int)$newRating
                )
            )
            ->execute();*/
    }

    public function getRating($ratable)
    {
        return 3;
        /*return dibi::select("AVG(rating)")
            ->from('ratings')
            ->where('product_id = %i', $ratable)
            ->fetchSingle();*/
    }

    public function getUniqueId($ratable)
    {
        return $ratable;
    }

    public function getVoteCount($ratable)
    {
        return 10;
        /*return dibi::select('count(*)')
            ->from('ratings')
            ->where('product_id = %i', $ratable)
            ->fetchSingle();*/
    }

    public function wasVoted($id)
    {
        $session = Environment::getSession('rating'.$id);
        if(isset($session->wasVoted))
            return $session->wasVoted;
        else
            return false;
    }
}