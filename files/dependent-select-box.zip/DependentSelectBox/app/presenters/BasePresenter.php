<?php
use Nette\Application\Presenter;
use Nette\Application\AppForm;
use Nette\Forms\Form;
use DependentSelectBox\DependentSelectBox;
use Nette\Forms\FormContainer;

class BasePresenter extends Presenter {
	/** @persistent */
	public $noJs;


	/** @persistent */
	public $selectFirst;

	protected $hodnoty = null;


	public function startup() {
		parent::startup();
		\Nette\Forms\FormContainer::extensionMethod("addDependentSelectBox", "DependentSelectBox\DependentSelectBox::formAddDependentSelectBox");
		\Nette\Forms\FormContainer::extensionMethod("addJsonDependentSelectBox", "DependentSelectBox\JsonDependentSelectBox::formAddJsonDependentSelectBox");
		DependentSelectBox::$disableChilds = $this->selectFirst === null;
	}



	public function renderDefault()	{
		$this->template->noJs = $this->noJs;
		$this->template->selectFirst = $this->selectFirst;
		if(isset($this->hodnoty))
			$this->template->hodnoty = $this->hodnoty;
	}



}
