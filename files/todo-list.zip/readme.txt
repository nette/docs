Nette Framework skeleton
========================

The basic structure for your application.



Installing
----------

Download Nette Framework (http://nette.org/download) and extract the folder 'Nette' to your project's library directory 'libs'.
Your library directory should now contain the Nette directory which contains all of the Nette Framework units. Now the Nette Framework is
successfully installed and ready to use.

Make directories 'app/temp' and 'app/log' writable.



SECURITY WARNING
----------------

It is CRITICAL that file 'app/config.ini' & whole 'app' directory are NOT accessible directly via a web browser!
If you don't protect this directory from direct web access, anybody will be able to see your sensitive data.
See: http://nette.org/security-warning
