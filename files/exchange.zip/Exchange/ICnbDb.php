<?php

namespace Exchange;

interface ICnbDB
{
    const CNB_YEAR  = 'http://www.cnb.cz/cs/financni_trhy/devizovy_trh/kurzy_devizoveho_trhu/rok.txt?rok=';
    const CNB_YEAR2 = 'http://www.cnb.cz/cs/financni_trhy/devizovy_trh/kurzy_ostatnich_men/rok.txt?rok=';

    //const CNB_YEAR   ='D:\_';
    //const CNB_YEAR2  ='D:\_2';

    const T_CNB = 'cnb';
    const C_ID_CURRENCY = 'id_currency';
    const C_FORMAT = 'format';
    const C_CODE = 'code';
    const C_DECIMAL = 'decimal';
    const C_DECPOINT = 'decpoint';
    const C_THOUSANDS = 'thousands';
    const C_SYMBOL = 'symbol';
    const C_FROM = 'from';
    const C_COUNTRY = 'country';
    const C_NAME = 'name';

    const T_CNB_RATE = 'cnb_rate';
    const C_ID_RATE = 'id_rate';
    const C_OID_CURRENCY = 'oid_currency';
    const C_OID_HISTORY = 'oid_history';
    const C_TO = 'to';
    const C_RATE = 'rate';
    const C_STATUS = 'status';

    const T_CNB_HISTORY = 'cnb_history';
    const C_ID_HISTORY = 'id_history';
    const C_DATE = 'date';
}
