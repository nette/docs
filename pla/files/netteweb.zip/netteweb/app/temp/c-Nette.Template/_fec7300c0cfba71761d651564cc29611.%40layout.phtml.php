<?php //netteCache[01]000235a:2:{s:4:"time";s:21:"0.42376800 1264566976";s:9:"callbacks";a:1:{i:0;a:3:{i:0;a:2:{i:0;s:5:"Cache";i:1;s:9:"checkFile";}i:1;s:80:"C:\Inetpub\wwwroot\test\Fepo_nette\document_root/../app/templates//@layout.phtml";i:2;i:1264566975;}}}?><?php
// file …/templates//@layout.phtml
//

$_cb = LatteMacros::initRuntime($template, NULL, '0101ba5c18'); unset($_extends);

if (SnippetHelper::$outputAllowed) {
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

	<meta name="description" content="Nette Framework web application skeleton"><?php if (isset($robots)): ?>
	<meta name="robots" content="<?php echo TemplateHelpers::escapeHtml($robots) ?>">
<?php endif ?>

<?php LatteMacros::callBlock($_cb->blocks, 'title', get_defined_vars()) ?>

	<link rel="stylesheet" media="screen,projection,tv" href="<?php echo TemplateHelpers::escapeHtml($basePath) ?>/css/screen.css" type="text/css">
	<link rel="shortcut icon" href="<?php echo TemplateHelpers::escapeHtml($basePath) ?>/favicon.ico" type="image/x-icon">
</head>

<body>
<div id="header">
	<h1>Nette Fabrika, s.r.o.</h1>

	<h2>Otevřeli jsme továrnu na sny...</h2>
</div>
	<ul>
<?php foreach ($iterator = $_cb->its[] = new SmartCachingIterator($menuItems) as $id=>$item): ?>
<li <?php try { $presenter->link($id); } catch (InvalidLinkException $e) {}; if ($presenter->getLastCreatedRequestFlag("current")): ?>class="current"<?php endif ?>><a href="<?php echo TemplateHelpers::escapeHtml($presenter->link($id)) ?>"><?php echo TemplateHelpers::escapeHtml($item) ?></a></li>
<?php endforeach; array_pop($_cb->its); $iterator = end($_cb->its) ?>
</ul>

<?php LatteMacros::callBlock($_cb->blocks, 'content', get_defined_vars()) ?>

</body>
</html>
<?php
}
