<?php

/**
 * Rating Control
 * Simple class for generating star-like rating control
 * (eg. for rating articles, products, ..)
 *
 * @author Radek Je�d�k
 * @version 0.2
 * @license New BSD License
 * @package Nette\Extras\RatingControl
 */
class RatingControl extends Control {

    /**
     * Model interface instance for getting rating information
     * @var IRatingModel
     */
    private $model = null;
    /**
     * Number of stars, default 5 stars
     * @var int
     */
    private $total = 5;
    /**
     * Already voted?
     * @var bool
     */
    private $voted = false;
    /**
     * Template filename
     * @var string
     */
    private $templateFile;

    /**
     * Sets Rating Model, to get the information from
     * @param IRatingModel implementation
     */
    public function setRatingModel(IRatingModel $model) {
        $this->model = $model;
    }

    /**
     * Return total number of stars
     */
    public function getTotal() {
        return $this->total;
    }

    /**
     * Sets total number of stars
     * @param int
     */
    public function setTotal($stars) {
        $this->total = $stars;
    }

    /**
     * Rate signal, user voted
     * @param int unique ID of rating control
     * @param int new rating specified by user
     */
    public function handleRate($id, $newRating) {
        if($this->model->wasVoted($id))
            return;

        $newRating = max(1, (int) $newRating);
        $newRating = min($newRating, $this->total);

        $this->voted = true;
        $this->model->addRating($id, $newRating);
        $this->flashMessage('thank you for voting!', $id);
        $this->invalidateControl();
    }

    public function setTemplateFile($file) {
        $this->templateFile = $file;
    }

    public function getTemplateFile() {
        return $this->templateFile;
    }

    /**
     * Renders the rating control
     *
     * @param mixed variable passed to RatingModel methods
     */
    public function render($ratable) {
        if($this->model == null)
            throw new InvalidStateException("Model object implementing IRatingModel interface must be set in RatingControl instance.");

        if($this->templateFile != false)
            $this->template->setFile($this->templateFile);
        else
            $this->template->setFile(dirname(__FILE__) . "/ratingControl.phtml");

        $this->template->total = $this->total;

        $this->template->id = $this->model->getUniqueId($ratable);
        $this->template->voteCount = (int) $this->model->getVoteCount($ratable);
        $this->template->voted = $this->model->wasVoted($this->template->id);

        $stars = array();
        $rating = round((float) $this->model->getRating($ratable));
        for($i = 1; $i <= $this->total; $i++)
            $stars[$i] = (bool) ($i <= $rating);

        $this->template->stars = $stars;

        $this->template->render();
    }

}