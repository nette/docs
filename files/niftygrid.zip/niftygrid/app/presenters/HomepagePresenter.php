<?php

/**
 * Homepage presenter.
 *
 * @author     John Doe
 * @package    MyApplication
 */
class HomepagePresenter extends BasePresenter
{

	protected function createComponentArticleGrid()
	{
		return new ArticleGrid($this->context->database->table("article"));
	}
}
