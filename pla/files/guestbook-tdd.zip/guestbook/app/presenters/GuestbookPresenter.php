<?php
class GuestbookPresenter extends BasePresenter
{
	public $loggedIn = FALSE; // for unit testing

	public function renderDefault()
	{
		$guestbook = new Guestbook;
		$this->template->items = $guestbook->fetchAll();
		$this->template->user = Environment::getUser();
	}

	public function handleDelete($id)
	{
		$user = Environment::getUser();
		if(!$user->isAuthenticated() && !$this->loggedIn) {
			throw new ForbiddenRequestException();
		}
		$guestbook = new Guestbook;
		$guestbook->delete($id);
		$this->flashMessage('Příspěvek byl smazán.');
		$this->invalidateControl();
		if(!$this->isAjax())
			$this->redirect('Guestbook:');
	}

	public function createComponentAddItemForm()
	{
		$form = new AppForm;
		$form->addText('author', 'Vaše jméno')
			 ->addRule(Form::FILLED, 'Musíte vyplnit Vaše jméno!');
		$form->addText('email', 'Váš e-mail')
			 ->addCondition(Form::FILLED)
				->addRule(Form::EMAIL, 'Zadal jste neplatnou e-mailovou adresu.');
		$form->addText('title', 'Nadpis')
			 ->addRule(Form::FILLED, 'Musíte vyplnit nadpis!');
		$form->addTextArea('content', 'Obsah')
			 ->addRule(Form::FILLED, 'Musíte vyplnit obsah příspěvku!');
		$form->addSubmit('save', 'Uložit')
			 ->onClick[] = array($this, 'addItem');

		return $form;
	}

	public function addItem(SubmitButton $button)
	{
		$form = $button->getForm();
		$values = $form->getValues();
		$values['added'] = new DateTime;

		$model = new Guestbook;
		$model->insert($values);
		$this->flashMessage('Váš příspěvek byl přidán.');
		$this->invalidateControl();
		if(!$this->isAjax())
			$this->redirect('Guestbook:');
	}
}