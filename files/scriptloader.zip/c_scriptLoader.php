<?php
/**
 * v 0.2.1
 * funguje s nette 0.9
 * @todo mezera v css na zacatku
 *
 */
class ScriptLoader extends Object
{
    private $temp = false;

    private $found  =array("~[\t\x0B\f\r]~m" , "~^@.*$~Um" , "~\n~" , '~[ ]+~' , '~;}~');
    private $change =array('' , '' , '' , ' ' , '}');

    const CSS = '.css';
    const JS = '.js';
    /**
     * zapne nebo vypne html tagovani
     *  true = on, false = off
     * @var bool
     */
    private $link;
    /**
     * .css nebo .js
     * @var file type
     */
    private $type;
    public static $media = 'screen, projection';
    public static $webTemp = false;
    private $compresion;

    /**
     * nastavi si temp dir a zda ma po zpracovani vratit <link />
     * @param bool $tag
     * @param bool $temp -moznost nastavit jiny aplikacni temp
     * @return void
     */
    public function __construct ($compresion=null, $tag=true)
    {
        $this->link     =(bool) $tag;
        $this->temp     =Environment::getVariable('tempDir');
        $this->compresion       =$compresion;
    }

    /**
     * smazani weboveho temp adresare
     */
    public function clearTemp($clear=0)
    {
        $time   =time() - $clear;
        foreach (new DirectoryIterator(self::getWebTemp()) as $fileInfo)
        {
            if($fileInfo->isFile() && $time > $fileInfo->getCtime())
            {
                unlink($fileInfo->getPathname());
            }
        }
    }

    /**
     * moznost prenastavit vykreslovani tagu po zavolani instance
     *
     * @param bool $on
     */
    public function setTag ($on = TRUE)
    {
        $this->link = (bool) $on;
    }

    /**
     * seznam javascriptovych souboru
     * @return tag|array
     */
    public function addJs ()
    {
        $this->type = self::JS;
        $arg['js'] = self::argCorection(func_get_args());
        return self::addScript($arg);
    }
    /**
     * seznam kaskadovych stylu
     * @return tag|array
     */
    public function addCss ()
    {
        $this->type = self::CSS;
        $arg = self::argCorection(func_get_args());
        if (is_int(key($arg)))
        {
            $arg = array(self::$media => $arg);
        }
        return self::addScript($arg);
    }

    /**
     *
     * @param array $array
     * @return array
     */
    private function argCorection (array $array)
    {
        if (! isset($array[1]) && isset($array[0]) && is_array($array[0]))
        {
            $array = $array[0];
        }
        return $array;
    }

    /**
     * pridani pole, stringu a matice se seznamem nazvu souboru, zvlast css a js
     * @return void
     */
    private function addScript (array $arg)
    {
        $environs   =Environment::getMode('production');
        $webTemp    =self::getWebTemp();
        $url        =self::makeUri();
        $link       =null;

        if($environs === false)
        {
            self::clearTemp(3600);
        }

        if($this->compresion === null && $environs === true || $this->compresion == true)
        {
            $this->compresion   =true;
        }
        else
        {
            $this->compresion   =false;
        }



        foreach ($arg as $media => $value)
        {
            $value  =array_unique((array) $value);
            $name   =null;
            $compressFile   =null;

            foreach ($value as $file)
            {
                $time   =filemtime($file);

                if ($time === false)
                {
                    throw new FileNotFoundException('This file "' . $file . '" does\'t exists.');
                }

                $name .= $time;
            }

            $fileName   =self::md5Name($name . $media) . $this->type;


            if(!file_exists($webTemp .'/'. $fileName) || $this->compresion === false)
            {
                foreach ($value as $file)
                {
                    $endActual = c_file::fileType($file, false);

                    if ($this->type != $endActual)
                    {
                        throw new InvalidStateException('This file "' . $endActual . '" must have same type "' . $this->type . '".');
                    }


                    if ($this->compresion === true)
                    {
                        $compressFile   .=$this->compressFile($file) .' ';
                    }
                    else
                    {
                        $fileName   =basename($file);

                        if((int)@filemtime($webTemp .'/'. $fileName) < filemtime($file))
                        {
                            file_put_contents($webTemp .'/'. $fileName, $this->compressFile($file));
                        }

                        if($this->link === true)
                        {
                            $link   .=$this->getLink($url . $fileName , $media);
                        }
                        else
                        {
                            $link[$media][]  =$url;
                        }
                    }
                }

                if($this->compresion === true)
                {
                    file_put_contents($webTemp .'/'. $fileName, $compressFile);
                }
            }

            if($this->compresion === true)
            {
                $link   .=self::getLink($url . $fileName, $media);
            }
        }

        return $link;
    }


    /**
     * komprese souboru a nahrazeni linku pro nacitani obrazku
     * @param $file
     * @return unknown_type
     */
    private function compressFile($file)
    {
        $urlImage = null;

        $original = file_get_contents($file);

        if ($this->type == '.css')
        {
/*
        //pro vyvoj
        foreach($found as $c => $val)
        {
            $original    =preg_replace($val, $change[$c], $original);
        }*/
            $original    =preg_replace($this->found, $this->change, $original);
            preg_match_all('~url\((.*)\)~U', $original, $urlImage);
            $urlImage = $urlImage[1];

            if (!empty($urlImage))
            {
                foreach ($urlImage as $klic => $val)
                { //nalezeny zaznamy prevede pomoci dirname aby se pak mohli odstranit duplicitni cesty array_unique
                    $val    =str_replace(array('"' , "'", ' '), '', $val);
                    $urlImage[$klic]    =dirname($val);
                }

                $urlImage   =array_unique($urlImage);

                foreach ($urlImage as $val)
                {
                    if (substr($val, 0, 4) != 'http')
                    {
                        if(substr($val, 0, 2) == '..')
                        {
                            $dir    =dirname($file) . c_file::DS . $val;
                        }
                        else
                        {
                            $dir    =realpath( $val );
                        }
                        $newUrl      =self::makeUri( $dir );
                        $original    =str_replace($val . '/', $newUrl, $original);
                    }
                }
            }
        }

        return $original;
    }

    /**
     * vytvori url na zaklade umisteni na disku
     *
     * @param string $folder
     * @return url
     */
    private function makeUri ($folder = false)
    {
        $front  =null;
        $back   =null;
        $new    =Environment::getHttpRequest();
        $url    =$new->getUri()->getBaseUri();
        $root   =realpath($_SERVER['DOCUMENT_ROOT'] . $new->getUri()->getBasePath());

        if ($folder === false)
        {
            $temp = self::getWebTemp();
        }
        else
        {
            $temp = realpath($folder);
            if ($temp === FALSE)
            {
                throw new FileNotFoundException('This folder "'. $folder .'" does\'t exists.');
            }
        }
        $root = explode(c_file::DS, $root);
        $temp = explode(c_file::DS, $temp);
        unset($root[0], $temp[0]);
        foreach ($root as $key => $value)
        {
            $issetT = isset($temp[$key]);
            if ($issetT && $value != $temp[$key])
            {
                $back .= '../';
                $front .= $temp[$key] . '/';
            } else
                if (! $issetT) {
                    $back .= '../';
                }
            unset($temp[$key]);
        }

        if (! empty($temp))
        {
            $front .= implode('/', $temp) . '/';
        }
        return $url . $back . $front;
    }

    /**
     * vytvori hash pomoci md5 a vrati prvnich 10 znaku
     * @param $value
     * @return string
     */
    static private function md5Name ($value)
    {
        return substr(md5($value), 0, 10);
    }

    /**
     *
     * @param $url
     * @param $media
     * @return html
     */
    private function getLink($url, $media)
    {
        if ($this->link === TRUE)
        {
            switch ($this->type)
            {
                case self::CSS:
                    $link = Html::el('link')->media($media)->type('text/css')->rel('stylesheet')->href($url);
                    break;
                case self::JS:
                    $link = Html::el('script')->src($url)->type('text/javascript');
                    break;
                default:
                    throw new InvalidStateException('Undefined file "' . $this->type . '"');
                    break;
            }
        }
        return $link ."\n";
    }

    /**
     * je potreba nastavi kam na webu se maji nove "cache" soubory ulozit
     * @param $folder
     * @return void
     */
    public function setWebTemp ($folder)
    {
        $folder = realpath($folder);
        if (is_writable($folder) && $folder !== FALSE) {
            self::$webTemp = $folder;
        } else {
            throw new DirectoryNotFoundException('Directory "' . $folder . '" does not exists or is not writeable.');
        }
    }

    /**
     * vrati cestu kam se ma soubor ulozit
     * @return dirname
     */
    static private function getWebTemp ()
    {
        if (self::$webTemp === FALSE) {
            throw new InvalidStateException('After create instance use method "setWebTemp" for setup writeable folder.');
        }
        return self::$webTemp;
    }
}
