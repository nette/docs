<?php

include"_setup.php";

$script =new ScriptLoader(true);
$script->setWebTemp(WWW_DIR .'/temp');



$a      =WWW_DIR .'/css/';
$css    =$script->addCss(array($a .'loader.css'));




echo $css;


function a($path)
{
Debug::dump(basename($path) .' - '. date('H:i:s', filemtime($path)));
}

$path   ='/home/matejcekm/workspace/pokus/temp/';

$a  =c_file::scandir($path, true, false);


foreach($a as $val)
{
    a($path . $val);
}