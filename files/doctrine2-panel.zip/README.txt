Doctine2 panel (c) Patrik Votoček (Vrtak-CZ) 2011 (http://patrik.votocek.cz)

Requirements
------------
Nette Framework 2.0-beta or higher. (PHP 5.3 edition)

Enable
------
For enable add $config->setSQLLogger(\Nella\Doctrine\Panel::register()); to your Doctrine inicialization.
