<?php

/**
 * My Application bootstrap file.
 *
 * @copyright  Copyright (c) 2010 John Doe
 * @package    MyApplication
 */



// Step 1: Load Nette Framework
// this allows load Nette Framework classes automatically so that
// you don't have to litter your code with 'require' statements
require LIBS_DIR . '/Nette/loader.php';



// Step 2: Configure environment
// 2a) enable Nette\Debug for better exception and error visualisation
Debug::enable();

// 2b) load configuration from config.ini file
Environment::loadConfig();

dibi::connect(Environment::getConfig('database'));

// Step 3: Configure application
// 3a) get and setup a front controller
$application = Environment::getApplication();
$application->errorPresenter = 'Error';
//$application->catchExceptions = TRUE;

Route::addStyle('do');
Route::addStyle('showDoneTasks');
Route::setStyleProperty('action', Route::FILTER_TABLE, array(
    'pridat-ukol' => 'add',
));
Route::setStyleProperty('do', Route::FILTER_TABLE, array(
    'smazat' => 'delete',
    'zmenit' => 'changeState',
    'submit' => 'todoForm-submit'
));
Route::setStyleProperty('showDoneTasks', Route::FILTER_TABLE, array(
    'hotove-ukoly' => 1, // 1 jako TRUE
));

// Step 4: Setup application router
$router = $application->getRouter();

$router[] = new Route('[<action>/]<do smazat|zmenit|submit>/', array(
    'presenter' => 'Todolist',
	'action' => 'show',
));

$router[] = new Route('<action pridat-ukol>', array(
    'presenter' => 'Todolist',
));

$router[] = new Route('[<showDoneTasks 0|hotove-ukoly>/][strana-<vp-page>]', array(
    'presenter' => 'Todolist',
    'action' => 'show',
    'showDoneTasks' => 0,
    'vp-page' => 1,
));


// Step 5: Run the application!
$application->run();
