SET NAMES utf8;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `tasks`;

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL auto_increment,
  `text` varchar(100) NOT NULL,
  `added` datetime NOT NULL,
  `done` enum('yes','no') NOT NULL default 'no',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into `tasks` values('1','úkol 1','2010-01-24 18:16:05','no'),
 ('2','úkol 2','2010-01-24 18:17:45','no'),
 ('3','úkol 3','2010-01-24 18:18:12','yes');

SET FOREIGN_KEY_CHECKS = 1;
