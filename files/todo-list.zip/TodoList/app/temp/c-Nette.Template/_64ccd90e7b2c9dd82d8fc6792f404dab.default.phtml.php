<?php //netteCache[01]000245a:2:{s:4:"time";s:21:"0.28623000 1264332782";s:9:"callbacks";a:1:{i:0;a:3:{i:0;a:2:{i:0;s:5:"Cache";i:1;s:9:"checkFile";}i:1;s:90:"/Users/inza/Projects/PHP/qs/TodoList/document_root/../app/templates/Homepage/default.phtml";i:2;i:1264207986;}}}?><?php
// file …/templates/Homepage/default.phtml
//

$_cb = LatteMacros::initRuntime($template, NULL, 'e9e9e7cbe8'); unset($_extends);


//
// block content
//
if (!function_exists($_cb->blocks['content'][] = '_cbb9c1774da84_content')) { function _cbb9c1774da84_content() { extract(func_get_arg(0))
?>

<div id="header">
	<h1>It works!</h1>

	<h2>Congratulations on your first Nette Framework powered page.</h2>
</div>

<div>
	<p><?php echo TemplateHelpers::escapeHtml($message) ?></p>
</div>

<style>
	body {
		margin: 0;
		padding 0;
	}

	div {
		padding: .2em 1em;
	}

	#header {
		background: #EEE;
		border-bottom: 1px #DDD solid;
	}

	h1 {
		color: #0056ad;
		font-size: 30px;
	}

	h2 {
		color: gray;
		font-size: 20px;
	}
</style><?php
}}

//
// end of blocks
//

if ($_cb->extends) { ob_start(); }

if (SnippetHelper::$outputAllowed) {
if (!$_cb->extends) { call_user_func(reset($_cb->blocks['content']), get_defined_vars()); }  
}

if ($_cb->extends) { ob_end_clean(); LatteMacros::includeTemplate($_cb->extends, get_defined_vars(), $template)->render(); }
