<?php

/**
 * PollControlPresenter - part of PollControl plugin for Nette Framework for voting.
 *
 * @copyright  Copyright (c) 2009 Ondřej Brejla
 * @license    New BSD License
 * @link       http://nettephp.com/cs/extras/poll-control
 * @package    Nette\Extras
 * @version    0.1
 */
class PollControlPresenter extends Presenter {

    public function beforeRender() {
        if (!Environment::getSession()->isStarted()) {
            Environment::getSession()->start();
        }
    }

    /**
     * Returns LinkPollControl component.
     *
     * @return PollControl Link poll control.
     */
    public function createComponentPollControl() {
        $poll = PollControl::factory('link');
        // alternatively:
        // $poll = new LinkPollControl();
        $poll->setModel(new PollControlModel(1));

        return $poll;
    }

    /**
     * Returns FormPollControl component.
     *
     * @return PollControl Form poll control.
     */
    public function createComponentPollControl2() {
        $poll = new FormPollControl();
        // alternatively:
        // $poll = PollControl::factory('form');
        $poll->setModel(new PollControlModel(1));

        return $poll;
    }

}
