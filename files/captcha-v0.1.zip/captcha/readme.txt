Captcha form control
--------------------

See http://nettephp.com/cs/extras/captcha for more info.
