<?php //netteCache[01]000245a:2:{s:4:"time";s:21:"0.61883000 1267274642";s:9:"callbacks";a:1:{i:0;a:3:{i:0;a:2:{i:0;s:5:"Cache";i:1;s:9:"checkFile";}i:1;s:90:"/opt/lampp/htdocs/NetteAjaxSelectBox/document_root/../app/templates/Homepage/default.phtml";i:2;i:1267274637;}}}?><?php
// file …/templates/Homepage/default.phtml
//

$_cb = LatteMacros::initRuntime($template, NULL, '46fb9242a6'); unset($_extends);


//
// block content
//
if (!function_exists($_cb->blocks['content'][] = '_cbbc73b6e7938_content')) { function _cbbc73b6e7938_content($_cb) { extract(func_get_arg(1))
?>

<div id="header">
	<h1>It works!</h1>

	<h2>Congratulations on your first Nette Framework powered page.</h2>
</div>

<div>
<div id="<?php echo $control->getSnippetId('form') ?>"><?php call_user_func(reset($_cb->blocks['_form']), $_cb, $template->getParams()) ?></div></div>

<style>
	body {
		margin: 0;
		padding: 0;
	}

	div {
		padding: .2em 1em;
	}

	#header {
		background: #EEE;
		border-bottom: 1px #DDD solid;
	}

	h1 {
		color: #0056ad;
		font-size: 30px;
	}

	h2 {
		color: gray;
		font-size: 20px;
	}
</style><?php
}}


//
// block _form
//
if (!function_exists($_cb->blocks['_form'][] = '_cbbb61e956d6d__form')) { function _cbbb61e956d6d__form($_cb) { extract(func_get_arg(1))
;if (is_object($form)) $form->render('begin'); else $control->getWidget($form)->render('begin') ?>
	<p><?php echo TemplateHelpers::escapeHtml($form['region']->label) ?> <?php echo TemplateHelpers::escapeHtml($form['region']->control) ?></p>
<?php if ($form['subregion']->showSelectBox()): ?>
	<p><?php echo TemplateHelpers::escapeHtml($form['subregion']->label) ?> <?php echo TemplateHelpers::escapeHtml($form['subregion']->control) ?></p>
<?php endif ?>
	<p><?php echo TemplateHelpers::escapeHtml($form['save']->control) ?></p>
<?php if (is_object($form)) $form->render('end'); else $control->getWidget($form)->render('end') ;
}}

//
// end of blocks
//

if ($_cb->extends) { ob_start(); }
elseif (isset($presenter, $control) && $presenter->isAjax()) { LatteMacros::renderSnippets($control, $_cb, get_defined_vars()); }

if (SnippetHelper::$outputAllowed) {
if (!$_cb->extends) { call_user_func(reset($_cb->blocks['content']), $_cb, $template->getParams()); }  
}

if ($_cb->extends) { ob_end_clean(); LatteMacros::includeTemplate($_cb->extends, get_defined_vars(), $template)->render(); }
