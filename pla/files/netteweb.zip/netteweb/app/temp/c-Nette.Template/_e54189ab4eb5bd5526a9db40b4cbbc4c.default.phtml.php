<?php //netteCache[01]000243a:2:{s:4:"time";s:21:"0.15330900 1264564159";s:9:"callbacks";a:1:{i:0;a:3:{i:0;a:2:{i:0;s:5:"Cache";i:1;s:9:"checkFile";}i:1;s:88:"C:\Inetpub\wwwroot\test\Fepo_nette\document_root/../app/templates/Products/default.phtml";i:2;i:1264563969;}}}?><?php
// file …/templates/Products/default.phtml
//

$_cb = LatteMacros::initRuntime($template, NULL, 'bc01b06781'); unset($_extends);


//
// block title
//
if (!function_exists($_cb->blocks['title'][] = '_cbb7b106e946a_title')) { function _cbb7b106e946a_title() { extract(func_get_arg(0))
?>

<title>Nette Fabrika, s.r.o. - Produkty</title>
<?php
}}


//
// block content
//
if (!function_exists($_cb->blocks['content'][] = '_cbbbc11f01689_content')) { function _cbbbc11f01689_content() { extract(func_get_arg(0))
?>
<div>
<p>Produkty Nette Fabriky!</p>
</div>
<?php
}}

//
// end of blocks
//

if ($_cb->extends) { ob_start(); }

if (SnippetHelper::$outputAllowed) {
?>
﻿<?php if (!$_cb->extends) { call_user_func(reset($_cb->blocks['title']), get_defined_vars()); }  if (!$_cb->extends) { call_user_func(reset($_cb->blocks['content']), get_defined_vars()); }  
}

if ($_cb->extends) { ob_end_clean(); LatteMacros::includeTemplate($_cb->extends, get_defined_vars(), $template)->render(); }
