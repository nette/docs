<?php

namespace Exchange;

/**
 * stahovaní kurzu z Raiffeisen Bank
 */
class RBank extends CnbFile
{
    const VALUTA_SALE = 'XML_RATE_TYPE_EBNK_SALE_VALUTA';
    const VALUTA_PURCHASE = 'XML_RATE_TYPE_EBNK_PURCHASE_VALUTA';
    const DEVIZA_SALE = 'XML_RATE_TYPE_EBNK_SALE_DEVIZA';
    const DEVIZA_PURCHASE = 'XML_RATE_TYPE_EBNK_PURCHASE_DEVIZA';
    const MIDDLE = 'XML_RATE_TYPE_EBNK_MIDDLE';

    const CODE = 'code';
    const FROM1 = 'from';

    protected $webRate = self::VALUTA_PURCHASE;
    protected $actualClass = 'RB';

//    const RB_LIST = 'http://www.rb.cz/views/components/rates/ratesXML.jsp';
    const RB_LIST = 'ratesXML.jsp';

    public function  __construct($webMoney = 0, $globalVat = false) {
        $this->loadBoth = false;
        parent::__construct($webMoney, $globalVat);
    }


    protected function  getSource1() {
        return self::RB_LIST;
    }

    protected function  createCache($cnb, $file)
    {
        $rate = array();
        $doc = new \DOMDocument();
        $doc->loadXML($cnb);
        $currencies = $doc->getElementsByTagName ('currency');

        foreach($currencies as $currency)
        {
            $type   = $currency->parentNode->getAttribute('type');
            $date   = $currency->parentNode->getAttribute('valid_from');
            $code   = $currency->getAttribute('name');
            $quota  = (int)$currency->getAttribute('quota');
            $rating = $currency->getAttribute('rate');

            if(!isset($rate[$code][self::NUM_FORMAT]))
                $rate[$code] = $this->createFormat($code);

            if(self::CODE !== false && !isset($rate[$code][self::CODE]))
                $rate[$code][self::CODE] = $code;

            if(self::FROM1 !== false && !isset($rate[$code][self::FROM1]))
                $rate[$code][self::FROM1] = $quota;

            $rate[$code][$type] = $quota / $rating;
        }

        $format = $this->createFormat('CZK');
        $rate['CZK'] = $format + array_fill_keys( array_keys( array_diff_key($rate[$code], $format) ), 1);

        if(isset($rate['CZK'][self::CODE]))
            $rate['CZK'][self::CODE] = 'CZK';

        $content = "<?php class ".$this->actualClass." extends NonObject{ ";
        foreach($rate as $key => $val)
        {
            $content .= 'public static function '. parent::correctTry($key) .'(){return ';
            $content .= preg_replace('~\s{2,}~', ' ', var_export($val, true)) .';}';
        }
        $content .= '}';
        file_put_contents($file, $content);
    }

    public function getRate($code=false)
    {
        if(!$code)
            $code = $this->webMoney;
        return $this->rating[$code][$this->webRate];
    }

    protected function getCalculationRate()
    {
        return $this->webRate;
    }
}
