<?php
use \NiftyGrid\Grid;

class ArticleGrid extends Grid
{
	protected $articles;

	public function __construct($articles)
	{
		parent::__construct();
		$this->articles = $articles;
	}

	protected function configure($presenter)
	{
		$source = new \NiftyGrid\NDataSource($this->articles->select('article.id, title, status, published, views, category.name AS category, user.username, user.id AS user_id'));

		$this->setDataSource($source);

		$this->setWidth("1000px");
		$this->setDefaultOrder("article.id DESC");
		$this->setPerPageValues(array(20, 50, 100));

		$this->addColumn('title', 'Titulek', '210px', 30)
			->setTextEditable()
			->setTextFilter()
			->setAutocomplete(5);

		$this->addColumn('username', 'Autor', '90px')
			->setTableName("user.username")
			->setTextFilter()
			->setAutocomplete(5)
			->setRenderer(function($row) use ($presenter){return \Nette\Utils\Html::el('a')->setText($row['username'])->href($presenter->link("user",$row['user_id']));})
			->setSelectEditable($presenter->context->database->table('user')->fetchPairs('id','username'));

		$this->addColumn('published', 'Datum', '110px')
			->setRenderer(function($row){return date('j.n.Y', strtotime($row['published']));})
			->setDateFilter()
			->setDateEditable()
			->setFormRenderer(function($row){return date('Y-m-d', strtotime($row['published']));});

		$categories = $presenter->context->database->table('category')->fetchPairs('id', 'name');

		$this->addColumn('category', 'Kategorie', '80px')
			->setTableName("category.name")
			->setSelectFilter($presenter->context->database->table('category')->fetchPairs('name', 'name'))
			->setSelectEditable($presenter->context->database->table('category')->fetchPairs('id', 'name'));

		$this->addColumn('status', 'Status', '100px')
			->setSelectFilter(array("Publikované" => "Publikované", "Nepublikované" => "Nepublikované"))
			->setSelectEditable(array("Publikované" => "Publikované", "Nepublikované" => "Nepublikované"));

		$this->addColumn('views', 'Zobrazení', '80px')
			->setNumericFilter()
			->setCellRenderer(function($row){return $row['views'] > 80 ? "background-color:#E4FFCC" : NULL;});

		$self = $this;

		$this->setRowFormCallback(function($values) use ($self, $presenter){
				$vals = array(
					"id" => $values["id"],
					"title" => $values["title"],
					"published" => $values["published"],
					"user_id" => $values["username"],
					"category_id" => $values["category"],
					"status" => $values["status"],
				);
				$presenter->context->database->table('article')->where("id", $vals["id"])->update($vals);
				$self->flashMessage("Záznam byl úspěšně uložen.","grid-successful");
			}
		);

		$this->addButton(Grid::ROW_FORM, "Rychlá editace")
			->setClass("fast-edit");

		$this->addButton("publish")
			->setLabel(function ($row) use ($self) {return $row['status'] == "Publikované" ? "Odpublikovat" : "Publikovat";})
			->setLink(function($row) use ($self){return $row['status'] == "Publikované" ? $self->link("unpublish!", $row['id']) : $self->link("publish!", $row['id']);})
			->setClass(function ($row) use ($self) {return $row['status'] == "Publikované" ? "unpublish" : "publish";});

		$this->addButton("edit", "Editovat")
			->setClass("edit")
			->setLink(function($row) use ($presenter){return /*$presenter->link("article:edit", $row['id'])*/ "#";})
			->setAjax(FALSE);

		$this->addButton("delete", "Smazat")
			->setClass("delete")
			->setLink(function($row) use ($self){return $self->link("delete!", $row['id']);})
			->setConfirmationDialog(function($row){return "Určitě chcete odstranit článek '$row[title]'?";});

		$this->addAction("publish","Publikovat")
			->setCallback(function($id) use ($self){return $self->handlePublish($id);});

		$this->addAction("unpublish","Odpublikovat")
			->setCallback(function($id) use ($self){return $self->handleUnpublish($id);});

		$this->addAction("delete","Smazat")
			->setCallback(function($id) use ($self){return $self->handleDelete($id);})
			->setConfirmationDialog("Určitě chcete smazat všechny vybrané članky?");

		$this->addSubGrid("comments", "Zobrazit komentáře k článku")
			->setGrid(new CommentGridByArticleId($presenter->context->database->table('comment'), $this->activeSubGridId))
			->settings(function($grid){
				$grid->setWidth("800px;");
			})
			->setCellStyle("background-color:#f6f6f6; padding:20px;");
	}

	public function handlePublish($id)
	{
		$this->presenter->context->database->table('article')->where("id", $id)->update(array("status" => "Publikované"));
		if(count($id) > 1){
			$this->flashMessage("Vybrané články byly úspěšně publikovány.","grid-successful");
		}else{
			$this->flashMessage("Článek byl úspěšně publikován.","grid-successful");
		}
		$this->redirect("this");
	}

	public function handleUnpublish($id)
	{
		$this->presenter->context->database->table('article')->where("id", $id)->update(array("status" => "Nepublikované"));
		if(count($id) > 1){
			$this->flashMessage("Vybrané články byly úspěšně odpublikovány.","grid-successful");
		}else{
			$this->flashMessage("Článek byl úspěšně odpublikován.","grid-successful");
		}
		$this->redirect("this");
	}

	public function handleDelete($id)
	{
		$this->flashMessage("V ukázkové aplikaci nelze mazat záznamy.", "grid-info");
	}
}
