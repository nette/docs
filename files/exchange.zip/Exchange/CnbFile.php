<?php

namespace Exchange;

use Utility\CUrl;

require_once __DIR__ .'/Cnb.php';

class CnbFile extends Cnb
{
    /**
     * download new currency
     * @return void
     */
    protected function loadList()
    {
        $new    =$this->getActualFile();
        $old    =$this->getOldFile($new);

        if((!file_exists( $new ) || (time() - @filemtime( $new ) > $this->refresh)))
        {
            $cnb2   =null;
            if(ini_get('allow_url_fopen') && parent::$proxyName === NULL)
            {
                $cnb    =@file_get_contents($this->getSource1());
                if($this->loadBoth)
                    $cnb2   =@file_get_contents($this->getSource2());
            }
            elseif(extension_loaded('curl'))
            {
                $curl   =new CUrl($this->getSource1());
                $this->setProxy($curl);
                $cnb    =$curl->getResult();
                if($curl->getErrorNumber() > 0)
                    throw new \RuntimeException('Let\'s check internet connection.');

                if($this->loadBoth)
                {
                    $curl   =new CUrl($this->getSource2());
                    $this->setProxy($curl);
                    $cnb2   =$curl->getResult();
                }
            }
            else
            {
                throw new \RuntimeException('This library need allow_url_fopen -enable or curl extension');
            }

            if( $cnb !== FALSE && $cnb2 !== FALSE )
            {
                $this->createCache(parent::stroke2point($cnb . $cnb2), $new);
            }
            elseif(($exis = file_exists($new)) || file_exists($old) )
            {
                if(!$exis)
                {
                    parent::rename($old, $new);
                }

                touch($new);
            }
            else
            {
                throw new \LogicException('You must connect to internet. It can\'t download rating list');
            }
        }

        if(!class_exists($this->actualClass))
            require_once $new;
    }


    /**
     * create cache file
     * @param string $cnb
     * @param $file name of cache file
     * @return void
     */
    protected function createCache($cnb, $file)
    {
        $cnb    = explode("\n", $cnb);
        unset($cnb[1]);
        $info   = explode(' #', $cnb[0]);
        $cnb[0] = Cnb::CNB_CZK;
        $obj    = new \ReflectionClass($this);
        $property = $this->getProperty();

        $list  ='<?php class '. $this->actualClass .'{static public $date=\''. $info[0] .'\';static public $id='. (int)$info[1] .';';

        $unique = array();

        foreach($cnb as $value)
        {
            $row    =explode(parent::PIPE, $value);

            if( !isset($row[4]) || !is_numeric($row[4]) || ($row[4] = (double)$row[4]) <= 0 )
                continue;
            else
                $row[2] =(double)$row[2];

            $try = self::correctTry($row[3]);
            if ( isset( $unique[$try] )) continue;
            $unique[$try] = true;

            $numFormat  =$this->createFormat($row[3]);
            $correction =$row[2]/$row[4];

            if($row[3] != $this->defMoney)
                $correction /=$this->correction;

            $list   .='public static function '. self::correctTry($row[3]) .'(){return array(';
            $list   .=self::getElement2Cache(parent::RATE, $correction);
            $list   .=self::getElement2Cache(parent::NUM_FORMAT, $numFormat);
            $list   .=self::getElement2Cache(parent::DECIMAL, $numFormat);
            $list   .=self::getElement2Cache(parent::DEC_POINT, $numFormat);
            $list   .=self::getElement2Cache(parent::THOUSANDS, $numFormat);
            $list   .=self::getElement2Cache(parent::SYMBOL, $numFormat);

            foreach($property as $key => $val)
            {
                if($val !== FALSE)
                    $list   .=self::getElement2Cache($val, $row[$key]);
            }

            $list   .=');}';
        }
        parent::rename($file, $this->getOldFile($file));
        unset($this->rating);
        file_put_contents($file, $list.'}');
    }

    /**
     * @see upper
     */
    protected function loadRating($code)
    {
        if(!isset($this->rating[$code]))
        {
            $array = @call_user_func(array($this->actualClass, self::correctTry($code)));
            if(!is_array($array))
            {
                if($this->isProduction())
                    return $this->defMoney;

                throw new \OutOfRangeException('This currency "'. $code .'" does not exist!');
            }

            $this->rating[$code] = $array;
        }

        return $code;
    }

    public function & getAllCode($codeSort = FALSE)
    {
        $reflection = new \ReflectionClass($this->actualClass);
        $array = $reflection->getMethods(\ReflectionMethod::IS_STATIC);
        array_walk($array, __CLASS__ .'::obj2array');
        if($codeSort)
        {
            sort($array);
            reset($array);
        }
        return $array;
    }

    public function loadCurrency(/*...*/)
    {
        $args = func_get_args();
        if(is_array($args[0]))
            $args = $args[0];

        foreach ($args as &$val)
        {
            $val = strtoupper($val);
            $this->loadRating($val);
        }
        unset($val);
        return $args[0];
    }

    /**
     * correction for Turkish currency because try is reserved word in php
     * for load Turkish currency use its code 'try'
     * @param $string currency UPPERCASE
     * @return string
     */
    protected static function correctTry($string)
    {
        return ($string == 'TRY')? $string . '1': $string;
    }

    /**
     *
     * @param string|boolean $const
     * @param mixed $val
     * @return string
     */
    static private function getElement2Cache($const, &$val)
    {
        $v = is_array($val)? $val[$const]: $val;
        $v = is_numeric($v)? (double)$v: "'$v'";
        return "'$const'=>$v,";
    }

    /**
     * use for array_walk
     * @param \ReflectionMethod $item
     * @param int $key
     * @return void
     */
    static private function obj2array(\ReflectionMethod &$item, $key)
    {
        $item = ($item->name == 'TRY1')? 'TRY': $item->name;
    }
}