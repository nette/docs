<?php
class Todo extends DibiRow // dibirow obstará korektní načtení dat
{
	public function __construct($arr = array())
	{
		parent::__construct($arr);
	}

    public function delete()
    {
        return dibi::query("DELETE FROM [tasks] WHERE [id]=%i", $this->id);
    }

    public function save()
    {
        return dibi::query("UPDATE [tasks] SET", (array)$this, "WHERE [id]=%i", $this->id); // využijeme toho, že DibiRow dědí od ArrayObject
    }

	public function changeState()
	{
		$this->done = $this->done === 'yes' ? 'no' : 'yes';
		$this->save();
	}
}