<?php
/**
 * Nella
 *
 * @copyright  Copyright (c) 2006, 2010 Patrik Votoček
 * @license    http://nellacms.com/license  New BSD License
 * @link       http://nellacms.com
 * @category   Nella
 * @package    Nella
 */

namespace Nella;

use Nette\Environment;

/**
 * Callback panel for nette
 *
 * @copyright	Copyright (c) 2008, 2010 Patrik Votoček
 * @author		Patrik Votoček
 * @package		Nette
 */
class CallbackPanel extends \Nette\Object implements \Nette\IDebugPanel
{
	const VERSION = "1.3";
	/** @var array */
	private $items = array();
	/** @var bool */
	private static $registered = FALSE;
	
	public function __construct(array $items = NULL)
	{
		$this->items = array(
			'--temp' => array('callback' => callback($this, 'clearDir'), 'name' => "Clear Temp", 'args' => array(Environment::getVariable('tempDir'))),
			'--log' => array('callback' => callback($this, 'clearDir'), 'name' => "Clear Logs", 'args' => array(Environment::getVariable('logDir'))),
			'--sessions' => array('callback' => callback($this, 'clearDir'), 'name' => "Clear Sessions", 'args' => array(ini_get('session.save_path')))
		);
		if (!empty($items))
			$this->items = array_merge($this->items, $items);

		$this->processRequest();
	}

	/**
	 * Returns panel ID.
	 * @return string
	 * @see IDebugPanel::getId()
	 */
	public function getId()
	{
		return "callback-panel";
	}

	/**
	 * Renders HTML code for custom tab.
	 * @return string
	 * @see IDebugPanel::getTab()
	 */
	public function getTab()
	{
		ob_start();
		require_once __DIR__ . "/callback.tab.phtml";
		return ob_get_clean();
	}

	/**
	 * Renders HTML code for custom panel.
	 * @return string
	 * @see IDebugPanel::getPanel()
	 */
	public function getPanel()
	{
		$items = $this->items;
		ob_start();
		require_once __DIR__ . "/callback.panel.phtml";
		return ob_get_clean();
	}

	/**
	 * Handles an incomuing request and saves the data if necessary.
	 */
	public function processRequest()
	{
		$request = Environment::getHttpRequest();
		if ($request->isPost() && $request->isAjax() && $request->getHeader('X-Callback-Client')) {
			$data = json_decode(file_get_contents('php://input'), TRUE);
			if (count($data) > 0) {
				foreach ($data as $key => $value) {
					if (isset($this->items[$key]) && isset($this->items[$key]['callback']) && $value === TRUE) {
						callback($this->items[$key]['callback'])->invokeArgs($this->items[$key]['args']);
					}
				}
			}
			exit;
		}
	}

	/**
	 * Clean dir
	 *
	 * @param  $dir
	 */
	public function clearDir($dir)
	{
		foreach (glob($dir."/*") as $path) {
			if (is_dir($path)) {
				$this->clearDir($path);
				@rmdir($path);
			}
			else
				@unlink($path);
		}
	}

	/**
	 * Register this panel
	 *
	 * @param array $items items for add to pannel
	 */
	public static function register(array $items = NULL)
	{
		if (self::$registered)
			throw new \LocicalExceptin("Callback panel is already registered");
		
		\Nette\Debug::addPanel(new static($items));
		self::$registered = TRUE;
	}
}