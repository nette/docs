<?php

use Nette\Application\Presenter;
use Nette\Application\AppForm;
use Nette\Forms\Form;
use DependentSelectBox\DependentSelectBox;
use Nette\Forms\FormContainer;

class TreePresenter extends BasePresenter {




	public function actionDefault() {
		/*$this["form"]->setDefaults(array(
			"select1" => "|",
			"select3" => "b",
			"select2" => "C",
		));*/
	}


	public function getValuesSelect2($form) {
		return array(
			"a"=>$form["select1"]->getValue()." - a",
			"b"=>$form["select1"]->getValue()." - b",
			"c"=>$form["select1"]->getValue()." - c",
		);
	}

	public function getValuesSelect2_2($form) {
		return array(
			"A"=>$form["select1"]->getValue()." - A",
			"B"=>$form["select1"]->getValue()." - B",
			"C"=>$form["select1"]->getValue()." - C",
		);
	}

	public function getValuesSelect3($form) {
		return array(
			"1"=>$form["select1"]->getValue()." - ".$form["select2"]->getValue()." - 1",
			"2"=>$form["select1"]->getValue()." - ".$form["select2"]->getValue()." - 2",
			"3"=>$form["select1"]->getValue()." - ".$form["select2"]->getValue()." - 3",
		);
	}

	public function getValuesSelect3_2($form) {
		return array(
			"I"=>$form["select1"]->getValue()." - ".$form["select2_2"]->getValue()." - I",
			"II"=>$form["select1"]->getValue()." - ".$form["select2_2"]->getValue()." - II",
			"III"=>$form["select1"]->getValue()." - ".$form["select2_2"]->getValue()." - III",
		);
	}

	public function createComponentForm($name) {
		$form = new AppForm($this, $name);
		$form->addSelect("select1", "Výběr 1")->setItems(array("/"=>"Value = /", "|"=>"Value = |", "\\"=>"Value = \\"));


		$form->addDependentSelectBox("select2", "Výběr 2", $form["select1"], callback($this, "getValuesSelect2"));
		if($this->isAjax())
			$form["select2"]->addOnSubmitCallback(callback($this, "invalidateControl"), "formSnippet");

		$form->addDependentSelectBox("select2_2", "Výběr 2_2", $form["select1"], callback($this, "getValuesSelect2_2"));
		if($this->isAjax())
			$form["select2_2"]->addOnSubmitCallback(callback($this, "invalidateControl"), "formSnippet");

		$form->addDependentSelectBox("select3", "Výběr 3", $form["select2"], callback($this, "getValuesSelect3"));
		if($this->isAjax())
			$form["select3"]->addOnSubmitCallback(callback($this, "invalidateControl"), "formSnippet");

		$form->addDependentSelectBox("select3_2", "Výběr 3_2", $form["select2_2"], callback($this, "getValuesSelect3_2"));
		if($this->isAjax())
			$form["select3_2"]->addOnSubmitCallback(callback($this, "invalidateControl"), "formSnippet");

		$form->addSubmit("final_submit", "Hodnoty !")
			->onClick[] = callback($this, "submitForm");


		return $form;
	}

	public function submitForm($button) {
		$this->hodnoty = $button->form->values;
	}
}