<?php

abstract class BasePresenter extends Presenter
{
    
}
