<?php //netteCache[01]000231a:2:{s:4:"time";s:21:"0.30080100 1264565679";s:9:"callbacks";a:1:{i:0;a:3:{i:0;a:2:{i:0;s:5:"Cache";i:1;s:9:"checkFile";}i:1;s:76:"C:\Inetpub\wwwroot\test\Fepo_nette\document_root/../app/templates/menu.phtml";i:2;i:1264565668;}}}?><?php
// file …/templates/menu.phtml
//

$_cb = LatteMacros::initRuntime($template, NULL, '4325c23aad'); unset($_extends);

if (SnippetHelper::$outputAllowed) {
?>
﻿<ul>
<?php foreach ($iterator = $_cb->its[] = new SmartCachingIterator($menuItems) as $id=>$item): ?>
<li <?php try { $presenter->link($id); } catch (InvalidLinkException $e) {}; if ($presenter->getLastCreatedRequestFlag("current")): ?>class="current"<?php endif ?>><a href="<?php echo TemplateHelpers::escapeHtml($presenter->link($id)) ?>"><?php echo TemplateHelpers::escapeHtml($item) ?></a></li>
<?php endforeach; array_pop($_cb->its); $iterator = end($_cb->its) ?>
</ul>
<?php
}
