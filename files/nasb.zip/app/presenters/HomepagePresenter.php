<?php

/**
 * My Application
 *
 * @copyright  Copyright (c) 2010 John Doe
 * @package    MyApplication
 */



/**
 * Homepage presenter.
 *
 * @author     John Doe
 * @package    MyApplication
 */
class HomepagePresenter extends BasePresenter
{

	public function renderDefault()
	{
		$this->invalidateControl();
		$this->template->message = 'We hope you enjoy this framework!';
		$this->template->form = $this['testForm'];
	}

	public function createComponentTestForm()
	{
		$form = new AppForm;
		$form->getElementPrototype()->class('ajaxform');
		$form->addSelect('region', 'Kraj', array('Vyberte kraj') + (array)Regions::getParentRegions())
			  ->skipFirst()
			  ->addRule(Form::FILLED, 'Musíte vyplnit kraj!');
		$form->addAjaxSelect('subregion', 'Okres', Regions::getSubregions(), $form['region'])
			  ->addRule(Form::FILLED, 'Musíte vyplnit okres!');
		$form->addSubmit('save', 'OK');
		$form->onSubmit[] = callback($this, 'processTestForm');
		
		return $form;
	}

	public function processTestForm(AppForm $form)
	{
		
	}

}
