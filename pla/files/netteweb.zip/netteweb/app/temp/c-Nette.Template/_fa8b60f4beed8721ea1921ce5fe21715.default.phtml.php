<?php //netteCache[01]000242a:2:{s:4:"time";s:21:"0.40867800 1264564162";s:9:"callbacks";a:1:{i:0;a:3:{i:0;a:2:{i:0;s:5:"Cache";i:1;s:9:"checkFile";}i:1;s:87:"C:\Inetpub\wwwroot\test\Fepo_nette\document_root/../app/templates/Contact/default.phtml";i:2;i:1264563927;}}}?><?php
// file …/templates/Contact/default.phtml
//

$_cb = LatteMacros::initRuntime($template, NULL, '2ba9386e40'); unset($_extends);


//
// block title
//
if (!function_exists($_cb->blocks['title'][] = '_cbbfc4d3be4a1_title')) { function _cbbfc4d3be4a1_title() { extract(func_get_arg(0))
?>

<title>Nette Fabrika, s.r.o. - Kontakty</title>
<?php
}}


//
// block content
//
if (!function_exists($_cb->blocks['content'][] = '_cbbba5575cdc0_content')) { function _cbbba5575cdc0_content() { extract(func_get_arg(0))
?>
<div>
<p>Kontakty na Nette Fabriku!</p>
</div>
<?php
}}

//
// end of blocks
//

if ($_cb->extends) { ob_start(); }

if (SnippetHelper::$outputAllowed) {
?>
﻿<?php if (!$_cb->extends) { call_user_func(reset($_cb->blocks['title']), get_defined_vars()); }  if (!$_cb->extends) { call_user_func(reset($_cb->blocks['content']), get_defined_vars()); }  
}

if ($_cb->extends) { ob_end_clean(); LatteMacros::includeTemplate($_cb->extends, get_defined_vars(), $template)->render(); }
