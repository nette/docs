<?php

use Nette\Application\Presenter;
use Nette\Application\AppForm;
use Nette\Forms\Form;
use DependentSelectBox\DependentSelectBox;
use Nette\Forms\FormContainer;

class GraphPresenter extends BasePresenter {




	public function actionDefault() {

	}


	public function getValuesSelectZoom($form) {
		return array(
			1 => "1x - ". $form["size_x"]->getValue() . " x " . $form["size_y"]->getValue(),
			2 => "2x - ". 2*$form["size_x"]->getValue() . " x " . 2*$form["size_y"]->getValue(),
			4 => "4x - ". 4*$form["size_x"]->getValue() . " x " . 4*$form["size_y"]->getValue(),
		);
	}

	public function createComponentForm($name) {
		$form = new AppForm($this, $name);

		$form->addSelect("size_x", "Šířka")->setItems(
			array(320, 640, 800, 1024, 1240, 1440), false
		);

		$form->addSelect("size_y", "Výška")->setItems(
			array(240, 480, 600, 768, 900, 1024), false
		);


		$form->addDependentSelectBox("zoom", "Zvětšení", array($form["size_x"], $form["size_y"]), callback($this, "getValuesSelectZoom"))
			->addRule(Form::FILLED, "'%label' musí být vyplněno !");
		if($this->isAjax())
			$form["zoom"]->addOnSubmitCallback(callback($this, "invalidateControl"), "formSnippet");

		$form->addSubmit("final_submit", "Hodnoty !")
			->onClick[] = array($this, "submitForm");

		return $form;
	}

	public function submitForm($button) {
		$this->hodnoty = $button->form->values;
	}
}