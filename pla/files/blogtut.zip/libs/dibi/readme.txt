Dibi (c) David Grudl, 2005-2010 (http://davidgrudl.com)



Introduction
------------

Thank you for downloading Dibi!

Database access functions in PHP are not standardised. This is class library
to hide the differences between the different databases access.

The files in this archive are released under the Dibi license.
See license.txt in this directory for a copy of the license.



Documentation and Examples
--------------------------

Refer to the 'examples' directory for examples. Dibi documentation is
available on the homepage:

http://dibiphp.com



Dibi.minified
-------------

This is shrinked single-file version of whole Dibi, useful when you don't
want to modify library, but just use it.

This is exactly the same as normal version, just only comments and
whitespaces are removed.



-----
For more information, visit the author's weblog (in czech language):
http://phpfashion.com
