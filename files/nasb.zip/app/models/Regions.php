<?php
class Regions
{
	private static $regions = array(
		1 => 'Praha',
		2 => 'Plzeň',
	);
	private static $relationships = array(
		1 => array(1 => 'Praha 4', 2 => 'Praha 5', 3 => 'Praha 6'),
		2 => array(4 => 'Plzeň 1', 5 => 'Plzeň 2'),
	);

	public static function getSubregions()
	{
		return self::$relationships;
	}

	public static function getParentRegions()
	{
		return self::$regions;
	}
}
