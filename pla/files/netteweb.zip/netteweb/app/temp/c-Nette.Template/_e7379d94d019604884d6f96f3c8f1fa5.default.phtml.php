<?php //netteCache[01]000267a:2:{s:4:"time";s:21:"0.79548200 1264552614";s:9:"callbacks";a:1:{i:0;a:3:{i:0;a:2:{i:0;s:5:"Cache";i:1;s:9:"checkFile";}i:1;s:111:"C:\Inetpub\wwwroot\test\_libs_actual\nette\tools\Skeleton\document_root/../app/templates/Homepage/default.phtml";i:2;i:1264207986;}}}?><?php
// file …/templates/Homepage/default.phtml
//

$_cb = LatteMacros::initRuntime($template, NULL, 'fbd47bf133'); unset($_extends);


//
// block content
//
if (!function_exists($_cb->blocks['content'][] = '_cbb6a2e0e6627_content')) { function _cbb6a2e0e6627_content() { extract(func_get_arg(0))
?>

<div id="header">
	<h1>It works!</h1>

	<h2>Congratulations on your first Nette Framework powered page.</h2>
</div>

<div>
	<p><?php echo TemplateHelpers::escapeHtml($message) ?></p>
</div>

<style>
	body {
		margin: 0;
		padding 0;
	}

	div {
		padding: .2em 1em;
	}

	#header {
		background: #EEE;
		border-bottom: 1px #DDD solid;
	}

	h1 {
		color: #0056ad;
		font-size: 30px;
	}

	h2 {
		color: gray;
		font-size: 20px;
	}
</style><?php
}}

//
// end of blocks
//

if ($_cb->extends) { ob_start(); }

if (SnippetHelper::$outputAllowed) {
if (!$_cb->extends) { call_user_func(reset($_cb->blocks['content']), get_defined_vars()); }  
}

if ($_cb->extends) { ob_end_clean(); LatteMacros::includeTemplate($_cb->extends, get_defined_vars(), $template)->render(); }
