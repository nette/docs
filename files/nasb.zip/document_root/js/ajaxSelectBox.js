$(function() {
	$('.ajaxform select').live('change', function(event) {
		$(this).parents("form").ajaxSubmit();
		event.preventDefault();
	});
});