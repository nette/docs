<?php
class TodoManager
{
    public function findAllTodos($order = NULL, $where = NULL, $offset = NULL, $limit = NULL)
    {
        return dibi::query(
            "SELECT * FROM [tasks]",
            "%if", isset($where), "WHERE %and", isset($where) ? $where : array(), "%end",
            "%if", isset($order), "ORDER BY %by", $order, "%end",
            "%if", isset($limit), "LIMIT %i %end", $limit,
            "%if", isset($offset), "OFFSET %i %end", $offset
        )->setRowClass('Todo');
    }

	public function findTodo($id) {
		return dibi::query('SELECT * FROM [tasks] WHERE [id]=%i LIMIT 1', $id)
					 ->setRowClass('Todo')
					 ->fetch();
	}

	public function todoCount($where = NULL) {
		return dibi::fetchSingle('SELECT COUNT([id]) FROM [tasks] %if', isset($where),
									 'WHERE', isset($where) ? $where : array());
	}

    public function createTodo(Todo $todo)
    {
        return dibi::query("INSERT INTO [tasks]", (array)$todo);
    }
}