<?php
header('Content-Type: text/html; charset=utf-8');
//nette
define('WWW_DIR'    ,dirname(__FILE__));
define('APP_DIR'    ,WWW_DIR . '/app');
define('LIBS_DIR'   ,WWW_DIR . '/../libs/php');


define('TEMP_DIR'   ,APP_DIR . '/temp');
define('LOG_DIR'    ,APP_DIR . '/log');

require_once LIBS_DIR . '/myClass/_setup.php';
require_once LIBS_DIR . '/Nette/loader.php';
#/media/windows/www/pokus/app/temp
//Environment::setVariable('tempDir', '/media/KINGSTON/www/temp');
$session    =Environment::getSession();
$session    ->setExpiration(15552000);//180 dni
if (!$session->isStarted())
    $session->start();

$loader = new RobotLoader();
$loader->addDirectory(LIBS_DIR);
$loader->addDirectory(WWW_DIR);
$loader->addDirectory(TEMP_DIR . '/lang');
$loader->register();
//$loader->rebuild();
Debug::enable();
Debug::enableProfiler();
Debug::$counters['Last SQL query'] = & dibi::$sql;
Debug::$counters['Nette version']  = Framework::VERSION . ' ' . Framework::REVISION;
Debug::addColophon(array('dibi', 'getColophon'));
//konec nastavovani

//Debug::dump(DIRECTORY_SEPARATOR);

function dump($a, $b = false)
{
    Debug::dump($a, $b);
}
