<?php

use Nette\Application\Presenter;
use Nette\Application\AppForm;
use Nette\Forms\Form;
use DependentSelectBox\DependentSelectBox;
use DependentSelectBox\JsonDependentSelectBox;
use Nette\Forms\FormContainer;

class JsonLinePresenter extends BasePresenter {




	public function actionDefault() {
	}


	public function beforeRender() {
		JsonDependentSelectBox::tryJsonResponse();
	}

	public function getValuesSelect2($form) {
		return array(
			"A"=>$form["select1"]->getValue()." - A",
			"B"=>$form["select1"]->getValue()." - B",
			"C"=>$form["select1"]->getValue()." - C",
		);
	}

	public function getValuesSelect3($form) {
		return array(
			"a"=>$form["select1"]->getValue()." - ".$form["select2"]->getValue()." - a",
			"b"=>$form["select1"]->getValue()." - ".$form["select2"]->getValue()." - b",
			"c"=>$form["select1"]->getValue()." - ".$form["select2"]->getValue()." - c",
		);
	}

	public function getValuesSelect4($form) {
		return array(
			"1"=>$form["select1"]->getValue()." - ".$form["select2"]->getValue()." - ".$form["select3"]->getValue()." - 1",
			"2"=>$form["select1"]->getValue()." - ".$form["select2"]->getValue()." - ".$form["select3"]->getValue()." - 2",
			"3"=>$form["select1"]->getValue()." - ".$form["select2"]->getValue()." - ".$form["select3"]->getValue()." - 3",
		);
	}

	public function getValuesSelect5($form) {
		return array(
			"I"=>$form["select1"]->getValue()." - ".$form["select2"]->getValue()." - ".$form["select3"]->getValue()." - ".$form["select4"]->getValue()." - I",
			"II"=>$form["select1"]->getValue()." - ".$form["select2"]->getValue()." - ".$form["select3"]->getValue()." - ".$form["select4"]->getValue()." - II",
			"III"=>$form["select1"]->getValue()." - ".$form["select2"]->getValue()." - ".$form["select3"]->getValue()." - ".$form["select4"]->getValue()." - III",
		);
	}

	public function createComponentForm($name) {
		$form = new AppForm($this, $name);
		$form->addSelect("select1", "Výběr 1")->setItems(array("/"=>"Value = /", "|"=>"Value = |", "\\"=>"Value = \\"));


		$form->addJsonDependentSelectBox("select2", "Výběr 2", $form["select1"], callback($this, "getValuesSelect2"));

		$form->addJsonDependentSelectBox("select3", "Výběr 3", $form["select2"], callback($this, "getValuesSelect3"));

		$form->addJsonDependentSelectBox("select4", "Výběr 4", $form["select3"], callback($this, "getValuesSelect4"));

		$form->addJsonDependentSelectBox("select5", "Výběr 5", $form["select4"], callback($this, "getValuesSelect5"))
			->addRule(Form::FILLED, "'%label' musí být vyplněno !");

		$form->addSubmit("final_submit", "Hodnoty !")
			->onClick[] = callback($this, "submitForm");


		return $form;
	}

	public function submitForm($button) {
		$this->hodnoty = $button->form->values;
	}
}